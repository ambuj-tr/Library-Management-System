"""
validators.py - server-side input checks.

The browser also validates, but a client can always be bypassed (Postman, curl,
a modified page), so every important rule is enforced again here.

Each validate_* function returns a clean dictionary or raises ValidationError
carrying a {field: message} dictionary the frontend can show next to the inputs.
"""

import re
from datetime import date, datetime

EMAIL_PATTERN = re.compile(
    r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9\-]+(\.[A-Za-z0-9\-]+)*\.[A-Za-z]{2,}$"
)
ISBN_PATTERN = re.compile(r"^(\d{9}[\dX]|\d{13})$")
PHONE_CHARS = re.compile(r"^[0-9+\-\s()]+$")

MAX_COPIES = 10000


class ValidationError(Exception):
    """Raised when one or more fields are invalid."""

    def __init__(self, errors):
        super().__init__("Validation failed")
        self.errors = errors


def today_iso():
    return date.today().isoformat()


# --------------------------------------------------------------------------- #
# Small reusable checkers
# --------------------------------------------------------------------------- #
def _text(data, field, label, errors, max_len=150, min_len=1):
    value = data.get(field)
    if not isinstance(value, str) or not value.strip():
        errors[field] = f"{label} is required."
        return None
    value = " ".join(value.split())  # trim and collapse repeated spaces
    if len(value) < min_len:
        errors[field] = f"{label} must be at least {min_len} characters."
        return None
    if len(value) > max_len:
        errors[field] = f"{label} must be at most {max_len} characters."
        return None
    return value


def _whole_number(data, field, label, errors, minimum=1, maximum=MAX_COPIES):
    value = data.get(field)
    if isinstance(value, str) and re.fullmatch(r"\s*-?\d+\s*", value):
        value = int(value)
    # bool is a subclass of int in Python, so exclude it explicitly
    if isinstance(value, bool) or not isinstance(value, int):
        errors[field] = f"{label} must be a whole number."
        return None
    if value < 0:
        errors[field] = f"{label} cannot be negative."
        return None
    if value < minimum:
        errors[field] = f"{label} must be at least {minimum}."
        return None
    if value > maximum:
        errors[field] = f"{label} must be at most {maximum}."
        return None
    return value


def _date(data, field, label, errors, required=True):
    value = data.get(field)
    if value in (None, ""):
        if required:
            errors[field] = f"{label} is required."
        return None
    if not isinstance(value, str):
        errors[field] = f"{label} must be a date in YYYY-MM-DD format."
        return None
    try:
        parsed = datetime.strptime(value.strip(), "%Y-%m-%d").date()
    except ValueError:
        errors[field] = f"{label} must be a valid date in YYYY-MM-DD format."
        return None
    if parsed.year < 1900 or parsed.year > 2100:
        errors[field] = f"{label} must be between the years 1900 and 2100."
        return None
    return parsed.isoformat()


def normalize_isbn(raw):
    """'978-0-13-235088-4' -> '9780132350884' (also upper-cases a trailing x)."""
    return re.sub(r"[\s-]", "", raw).upper()


# --------------------------------------------------------------------------- #
# Books
# --------------------------------------------------------------------------- #
def validate_book(data):
    errors = {}
    clean = {
        "title": _text(data, "title", "Title", errors, max_len=200),
        "author": _text(data, "author", "Author", errors, max_len=150),
        "category": _text(data, "category", "Category", errors, max_len=60),
        "total_copies": _whole_number(data, "total_copies", "Total copies", errors, minimum=1),
    }

    isbn_raw = data.get("isbn")
    if not isinstance(isbn_raw, str) or not isbn_raw.strip():
        errors["isbn"] = "ISBN is required."
    else:
        isbn = normalize_isbn(isbn_raw)
        if not ISBN_PATTERN.match(isbn):
            errors["isbn"] = "ISBN must have 10 or 13 digits (hyphens are allowed; ISBN-10 may end in X)."
        else:
            clean["isbn"] = isbn

    if errors:
        raise ValidationError(errors)
    return clean


# --------------------------------------------------------------------------- #
# Members
# --------------------------------------------------------------------------- #
def validate_member(data, creating=True):
    errors = {}
    clean = {"name": _text(data, "name", "Full name", errors, max_len=100, min_len=2)}

    email = data.get("email")
    if not isinstance(email, str) or not email.strip():
        errors["email"] = "Email is required."
    else:
        email = email.strip().lower()
        if len(email) > 254 or not EMAIL_PATTERN.match(email):
            errors["email"] = "Enter a valid email address, for example name@example.com."
        else:
            clean["email"] = email

    phone = data.get("phone")
    if not isinstance(phone, str) or not phone.strip():
        errors["phone"] = "Phone number is required."
    else:
        phone = phone.strip()
        digits = re.sub(r"\D", "", phone)
        if not PHONE_CHARS.match(phone) or not 7 <= len(digits) <= 15:
            errors["phone"] = "Phone number must contain 7 to 15 digits (you may use + - ( ) and spaces)."
        else:
            clean["phone"] = phone

    if creating:
        registered = _date(data, "registration_date", "Registration date", errors, required=False)
        clean["registration_date"] = registered or today_iso()

    if errors:
        raise ValidationError(errors)
    return clean


# --------------------------------------------------------------------------- #
# Issue / return
# --------------------------------------------------------------------------- #
def validate_issue(data):
    errors = {}
    member_id = _whole_number(data, "member_id", "Member", errors, minimum=1, maximum=10**9)
    book_id = _whole_number(data, "book_id", "Book", errors, minimum=1, maximum=10**9)
    issue_date = _date(data, "issue_date", "Issue date", errors, required=False) or (
        None if "issue_date" in errors else today_iso()
    )
    due_date = _date(data, "due_date", "Due date", errors, required=True)

    if issue_date and due_date and due_date < issue_date:
        errors["due_date"] = "Due date cannot be earlier than the issue date."

    if errors:
        raise ValidationError(errors)
    return {"member_id": member_id, "book_id": book_id, "issue_date": issue_date, "due_date": due_date}


def validate_return(data):
    errors = {}
    transaction_id = _whole_number(data, "transaction_id", "Transaction", errors, minimum=1, maximum=10**9)
    return_date = _date(data, "return_date", "Return date", errors, required=False) or (
        None if "return_date" in errors else today_iso()
    )
    if errors:
        raise ValidationError(errors)
    return {"transaction_id": transaction_id, "return_date": return_date}

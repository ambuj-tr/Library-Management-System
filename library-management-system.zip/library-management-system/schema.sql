-- Library Management System - SQLite schema
-- This file is executed automatically every time the app starts.
-- "IF NOT EXISTS" makes it safe to run again and again.

CREATE TABLE IF NOT EXISTS books (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    title            TEXT    NOT NULL,
    author           TEXT    NOT NULL,
    isbn             TEXT    UNIQUE NOT NULL,
    category         TEXT    NOT NULL,
    total_copies     INTEGER NOT NULL,
    available_copies INTEGER NOT NULL,
    -- Extra safety nets: even a buggy query cannot create negative stock.
    CHECK (total_copies >= 1),
    CHECK (available_copies >= 0),
    CHECK (available_copies <= total_copies)
);

CREATE TABLE IF NOT EXISTS members (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    name              TEXT NOT NULL,
    email             TEXT UNIQUE NOT NULL,
    phone             TEXT NOT NULL,
    registration_date TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS transactions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id     INTEGER NOT NULL,
    member_id   INTEGER NOT NULL,
    issue_date  TEXT    NOT NULL,
    due_date    TEXT    NOT NULL,
    return_date TEXT    NULL,
    status      TEXT    NOT NULL DEFAULT 'Issued',
    FOREIGN KEY (book_id)   REFERENCES books(id),
    FOREIGN KEY (member_id) REFERENCES members(id),
    CHECK (status IN ('Issued', 'Returned')),
    CHECK (due_date >= issue_date),
    -- An issued book has no return date; a returned book always has one.
    CHECK (
        (status = 'Issued'   AND return_date IS NULL) OR
        (status = 'Returned' AND return_date IS NOT NULL)
    )
);

CREATE INDEX IF NOT EXISTS idx_transactions_status ON transactions(status);
CREATE INDEX IF NOT EXISTS idx_transactions_book   ON transactions(book_id);
CREATE INDEX IF NOT EXISTS idx_transactions_member ON transactions(member_id);

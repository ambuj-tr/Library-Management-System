"""
database.py - everything that talks to SQLite directly lives here.

Responsibilities
  * open connections (with foreign keys switched ON)
  * create the tables from schema.sql automatically
  * give the rest of the app a safe `transaction()` helper
  * insert sample data the first time the database is empty

Run `python database.py` to create/seed the database without starting Flask,
or `python database.py --reset` to delete it and start fresh.
"""

import os
import sqlite3
import sys
from contextlib import contextmanager
from datetime import date, timedelta

from flask import g

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SCHEMA_PATH = os.path.join(BASE_DIR, "schema.sql")


def get_db_path():
    """Database file location. Can be overridden with the LIBRARY_DB variable
    (the automated tests use this so they never touch your real data)."""
    return os.environ.get("LIBRARY_DB", os.path.join(BASE_DIR, "library.db"))


def connect():
    """Open a new SQLite connection.

    isolation_level=None  -> we control BEGIN/COMMIT ourselves (see transaction()).
    PRAGMA foreign_keys   -> SQLite ignores foreign keys unless this is ON for
                             EVERY connection, so we set it here.
    """
    conn = sqlite3.connect(get_db_path(), timeout=10, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


# --------------------------------------------------------------------------- #
# Per-request connection (used by Flask routes)
# --------------------------------------------------------------------------- #
def get_db():
    """Return the connection for the current request, opening it if needed."""
    if "db" not in g:
        g.db = connect()
    return g.db


def close_db(_error=None):
    """Called by Flask at the end of every request."""
    db = g.pop("db", None)
    if db is not None:
        db.close()


@contextmanager
def transaction(db):
    """Run several statements as ONE all-or-nothing unit.

    BEGIN IMMEDIATE takes the write lock straight away, so two people issuing
    the last copy of a book at the same moment cannot both succeed.
    If anything raises an error inside the `with` block, everything is rolled
    back and the error continues upward (it is never swallowed).
    """
    db.execute("BEGIN IMMEDIATE")
    try:
        yield db
        db.execute("COMMIT")
    except BaseException:
        if db.in_transaction:
            db.execute("ROLLBACK")
        raise


# --------------------------------------------------------------------------- #
# Schema + sample data
# --------------------------------------------------------------------------- #
def init_db():
    """Create tables if missing and add demo data if the database is empty."""
    conn = connect()
    try:
        with open(SCHEMA_PATH, "r", encoding="utf-8") as schema_file:
            conn.executescript(schema_file.read())
        conn.execute("PRAGMA foreign_keys = ON")
        empty = (
            conn.execute("SELECT COUNT(*) FROM books").fetchone()[0] == 0
            and conn.execute("SELECT COUNT(*) FROM members").fetchone()[0] == 0
        )
        if empty:
            seed_sample_data(conn)
    finally:
        conn.close()


def _days_ago(n):
    return (date.today() - timedelta(days=n)).isoformat()


def _days_ahead(n):
    return (date.today() + timedelta(days=n)).isoformat()


def seed_sample_data(conn):
    """Insert demo books, members and a few transactions.

    Dates are relative to today so the dashboard always looks alive
    (one issued book is intentionally overdue).
    """
    books = [
        ("Clean Code", "Robert C. Martin", "9780132350884", "Programming", 4),
        ("The Pragmatic Programmer", "David Thomas, Andrew Hunt", "9780135957059", "Programming", 3),
        ("Fluent Python", "Luciano Ramalho", "9781492056355", "Programming", 2),
        ("Python Crash Course", "Eric Matthes", "9781593279288", "Programming", 5),
        ("Flask Web Development", "Miguel Grinberg", "9781491991732", "Web Development", 2),
        ("Automate the Boring Stuff with Python", "Al Sweigart", "9781593279929", "Programming", 3),
        ("Introduction to Algorithms", "Thomas H. Cormen et al.", "9780262033848", "Computer Science", 3),
        ("Deep Learning", "Ian Goodfellow, Yoshua Bengio, Aaron Courville", "9780262035613", "Artificial Intelligence", 2),
        ("Hands-On Machine Learning", "Aurelien Geron", "9781492032649", "Artificial Intelligence", 3),
        ("Digital Design", "M. Morris Mano", "9780134549897", "Electronics", 4),
        ("Concepts of Physics, Vol. 1", "H. C. Verma", "9788177091878", "Physics", 6),
        ("A Brief History of Time", "Stephen Hawking", "9780553380163", "Science", 2),
        ("Wings of Fire", "A. P. J. Abdul Kalam", "9788173711466", "Biography", 3),
        ("The Discovery of India", "Jawaharlal Nehru", "9780143031031", "History", 2),
        ("The God of Small Things", "Arundhati Roy", "9780812979657", "Fiction", 2),
        ("Sapiens", "Yuval Noah Harari", "9780062316110", "History", 1),
    ]
    members = [
        ("Aarav Deshmukh", "aarav.deshmukh@example.com", "9822012345", 120),
        ("Priya Kulkarni", "priya.kulkarni@example.com", "9890123456", 95),
        ("Rohan Patil", "rohan.patil@example.com", "9765432109", 80),
        ("Sneha Joshi", "sneha.joshi@example.com", "9421098765", 64),
        ("Kabir Sharma", "kabir.sharma@example.com", "9552233445", 40),
        ("Ananya Iyer", "ananya.iyer@example.com", "9373344556", 22),
        ("Mihir Thakre", "mihir.thakre@example.com", "9604455667", 9),
    ]
    # (book index, member index, issued N days ago, loan length in days,
    #  returned N days ago or None for "still issued")
    loans = [
        (0, 0, 40, 14, 28),
        (3, 1, 33, 14, 20),
        (6, 2, 20, 14, 9),
        (7, 3, 12, 14, 5),
        (1, 1, 3, 14, None),
        (4, 4, 25, 14, None),   # overdue
        (7, 0, 8, 14, None),
        (15, 2, 5, 7, None),    # the only copy of Sapiens is out
    ]

    conn.execute("BEGIN IMMEDIATE")
    try:
        book_ids = []
        for title, author, isbn, category, copies in books:
            cur = conn.execute(
                "INSERT INTO books (title, author, isbn, category, total_copies, available_copies) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (title, author, isbn, category, copies, copies),
            )
            book_ids.append(cur.lastrowid)

        member_ids = []
        for name, email, phone, joined_days_ago in members:
            cur = conn.execute(
                "INSERT INTO members (name, email, phone, registration_date) VALUES (?, ?, ?, ?)",
                (name, email, phone, _days_ago(joined_days_ago)),
            )
            member_ids.append(cur.lastrowid)

        for book_i, member_i, issued_ago, loan_days, returned_ago in loans:
            issue_date = _days_ago(issued_ago)
            due_date = (date.today() - timedelta(days=issued_ago) + timedelta(days=loan_days)).isoformat()
            if returned_ago is None:
                conn.execute(
                    "INSERT INTO transactions (book_id, member_id, issue_date, due_date, return_date, status) "
                    "VALUES (?, ?, ?, ?, NULL, 'Issued')",
                    (book_ids[book_i], member_ids[member_i], issue_date, due_date),
                )
                # keep stock in step with the active loan
                conn.execute(
                    "UPDATE books SET available_copies = available_copies - 1 WHERE id = ?",
                    (book_ids[book_i],),
                )
            else:
                conn.execute(
                    "INSERT INTO transactions (book_id, member_id, issue_date, due_date, return_date, status) "
                    "VALUES (?, ?, ?, ?, ?, 'Returned')",
                    (book_ids[book_i], member_ids[member_i], issue_date, due_date, _days_ago(returned_ago)),
                )
        conn.execute("COMMIT")
    except BaseException:
        if conn.in_transaction:
            conn.execute("ROLLBACK")
        raise


def reset_db():
    """Delete the database file and rebuild it with sample data."""
    path = get_db_path()
    if os.path.exists(path):
        os.remove(path)
    init_db()


if __name__ == "__main__":
    if "--reset" in sys.argv:
        reset_db()
        print(f"Database reset and re-seeded: {get_db_path()}")
    else:
        init_db()
        print(f"Database ready: {get_db_path()}")

"""
test_api.py - automated tests for the Library Management System API.

Run with:   python test_api.py
Uses a temporary database, so your real library.db is never touched.
"""

import os
import sqlite3
import tempfile
import unittest
from datetime import date, timedelta

# Point the app at a throw-away database BEFORE importing it.
_tmp_dir = tempfile.mkdtemp()
os.environ["LIBRARY_DB"] = os.path.join(_tmp_dir, "test_library.db")

import app as library_app  # noqa: E402
from database import connect, reset_db  # noqa: E402

TODAY = date.today().isoformat()
IN_14 = (date.today() + timedelta(days=14)).isoformat()
YESTERDAY = (date.today() - timedelta(days=1)).isoformat()


class LibraryApiTests(unittest.TestCase):
    def setUp(self):
        # Start every test from a clean, known database with NO sample data,
        # so the numbers asserted below are fully predictable.
        path = os.environ["LIBRARY_DB"]
        if os.path.exists(path):
            os.remove(path)
        conn = connect()
        with open(os.path.join(os.path.dirname(__file__), "schema.sql"), encoding="utf-8") as f:
            conn.executescript(f.read())
        conn.close()
        self.client = library_app.app.test_client()

    # ---- helpers ---------------------------------------------------------- #
    def add_book(self, isbn="9780132350884", copies=2, title="Clean Code", category="Programming"):
        return self.client.post("/api/books", json={
            "title": title, "author": "Robert C. Martin", "isbn": isbn,
            "category": category, "total_copies": copies,
        })

    def add_member(self, email="asha@example.com", name="Asha Rao"):
        return self.client.post("/api/members", json={
            "name": name, "email": email, "phone": "9876543210",
        })

    def issue(self, book_id, member_id, due=IN_14, issue=TODAY):
        return self.client.post("/api/transactions/issue", json={
            "book_id": book_id, "member_id": member_id, "issue_date": issue, "due_date": due,
        })

    def stats(self):
        return self.client.get("/api/dashboard/stats").get_json()["data"]

    def setup_book_and_member(self, copies=2):
        book = self.add_book(copies=copies).get_json()["data"]
        member = self.add_member().get_json()["data"]
        return book, member

    # ---- 1. Books CRUD ---------------------------------------------------- #
    def test_01_book_crud_and_search(self):
        r = self.add_book()
        self.assertEqual(r.status_code, 201)
        book = r.get_json()["data"]
        self.assertEqual(book["available_copies"], 2)
        self.assertEqual(book["availability"], "Available")

        listing = self.client.get("/api/books").get_json()
        self.assertEqual(listing["count"], 1)

        for term in ("clean", "martin", "978013", "978-0-13-235", "program"):
            found = self.client.get("/api/books/search", query_string={"q": term}).get_json()
            self.assertEqual(found["count"], 1, f"search term {term!r} should find the book")

        r = self.client.put(f"/api/books/{book['id']}", json={
            "title": "Clean Code (2nd copy)", "author": "Robert C. Martin",
            "isbn": "9780132350884", "category": "Software", "total_copies": 5,
        })
        self.assertEqual(r.status_code, 200)
        updated = r.get_json()["data"]
        self.assertEqual((updated["total_copies"], updated["available_copies"]), (5, 5))

        r = self.client.delete(f"/api/books/{book['id']}")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(self.client.get("/api/books").get_json()["count"], 0)

    def test_01b_book_validation(self):
        bad_payloads = [
            {},
            {"title": "", "author": "A", "isbn": "9780132350884", "category": "X", "total_copies": 1},
            {"title": "T", "author": "A", "isbn": "123", "category": "X", "total_copies": 1},
            {"title": "T", "author": "A", "isbn": "9780132350884", "category": "X", "total_copies": -3},
            {"title": "T", "author": "A", "isbn": "9780132350884", "category": "X", "total_copies": 0},
            {"title": "T", "author": "A", "isbn": "9780132350884", "category": "X", "total_copies": "abc"},
            {"title": "T", "author": "A", "isbn": "9780132350884", "category": "X", "total_copies": 2.5},
            {"title": "T", "author": "A", "isbn": "9780132350884", "category": "X", "total_copies": True},
        ]
        for payload in bad_payloads:
            r = self.client.post("/api/books", json=payload)
            self.assertEqual(r.status_code, 400, payload)
            self.assertFalse(r.get_json()["success"])
        self.assertEqual(self.client.get("/api/books").get_json()["count"], 0)

        # Not JSON at all
        r = self.client.post("/api/books", data="not json", content_type="text/plain")
        self.assertEqual(r.status_code, 400)

    # ---- 2. Members CRUD -------------------------------------------------- #
    def test_02_member_crud_and_search(self):
        r = self.add_member()
        self.assertEqual(r.status_code, 201)
        member = r.get_json()["data"]
        self.assertEqual(member["registration_date"], TODAY)

        self.assertEqual(self.client.get("/api/members").get_json()["count"], 1)
        for term in ("asha", "example.com", str(member["id"])):
            found = self.client.get("/api/members", query_string={"q": term}).get_json()
            self.assertEqual(found["count"], 1, term)
        self.assertEqual(self.client.get("/api/members", query_string={"q": "zzz"}).get_json()["count"], 0)

        r = self.client.put(f"/api/members/{member['id']}", json={
            "name": "Asha R. Rao", "email": "asha.rao@example.com", "phone": "+91 98765 43210",
        })
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["data"]["name"], "Asha R. Rao")

        self.assertEqual(self.client.delete(f"/api/members/{member['id']}").status_code, 200)
        self.assertEqual(self.client.get("/api/members").get_json()["count"], 0)

    def test_02b_member_validation(self):
        for payload in (
            {"name": "A", "email": "a@b.com", "phone": "9876543210"},
            {"name": "Asha", "email": "not-an-email", "phone": "9876543210"},
            {"name": "Asha", "email": "a@b.com", "phone": "12"},
            {"name": "Asha", "email": "a@b.com", "phone": "abcdefghij"},
            {"name": "", "email": "", "phone": ""},
        ):
            r = self.client.post("/api/members", json=payload)
            self.assertEqual(r.status_code, 400, payload)

    # ---- 3. Issue success + 10. dashboard --------------------------------- #
    def test_03_issue_available_book(self):
        book, member = self.setup_book_and_member(copies=2)
        r = self.issue(book["id"], member["id"])
        self.assertEqual(r.status_code, 201, r.get_json())
        txn = r.get_json()["data"]
        self.assertEqual(txn["status"], "Issued")
        self.assertIsNone(txn["return_date"])

        books = self.client.get("/api/books").get_json()["data"]
        self.assertEqual(books[0]["available_copies"], 1)

        s = self.stats()
        self.assertEqual((s["total_books"], s["total_copies"], s["available_books"], s["issued_books"], s["total_members"]),
                         (1, 2, 1, 1, 1))
        self.assertEqual(len(s["recent_transactions"]), 1)

    # ---- 4. Issue unavailable book ---------------------------------------- #
    def test_04_issue_unavailable_book(self):
        book, member = self.setup_book_and_member(copies=1)
        self.assertEqual(self.issue(book["id"], member["id"]).status_code, 201)
        r = self.issue(book["id"], member["id"])
        self.assertEqual(r.status_code, 409)
        self.assertIn("No copies", r.get_json()["error"])

        books = self.client.get("/api/books").get_json()["data"]
        self.assertEqual(books[0]["available_copies"], 0)  # never negative
        self.assertEqual(books[0]["availability"], "Unavailable")
        self.assertEqual(self.client.get("/api/transactions").get_json()["count"], 1)

        unavailable = self.client.get("/api/books", query_string={"availability": "unavailable"}).get_json()
        self.assertEqual(unavailable["count"], 1)
        available = self.client.get("/api/books", query_string={"availability": "available"}).get_json()
        self.assertEqual(available["count"], 0)

    def test_04b_issue_rules(self):
        book, member = self.setup_book_and_member()
        # Due date earlier than issue date
        r = self.issue(book["id"], member["id"], due=YESTERDAY, issue=TODAY)
        self.assertEqual(r.status_code, 400)
        # Unknown member / unknown book
        self.assertEqual(self.issue(book["id"], 9999).status_code, 404)
        self.assertEqual(self.issue(9999, member["id"]).status_code, 404)
        # Missing fields / bad dates
        r = self.client.post("/api/transactions/issue", json={"book_id": book["id"]})
        self.assertEqual(r.status_code, 400)
        r = self.client.post("/api/transactions/issue", json={
            "book_id": book["id"], "member_id": member["id"], "due_date": "31-12-2030"})
        self.assertEqual(r.status_code, 400)
        # Nothing was recorded and stock is untouched
        self.assertEqual(self.client.get("/api/transactions").get_json()["count"], 0)
        self.assertEqual(self.client.get("/api/books").get_json()["data"][0]["available_copies"], 2)

    # ---- 5. Return success ------------------------------------------------ #
    def test_05_return_book(self):
        book, member = self.setup_book_and_member(copies=2)
        txn = self.issue(book["id"], member["id"]).get_json()["data"]

        active = self.client.get("/api/transactions/active").get_json()
        self.assertEqual(active["count"], 1)

        r = self.client.post("/api/transactions/return", json={"transaction_id": txn["id"]})
        self.assertEqual(r.status_code, 200, r.get_json())
        returned = r.get_json()["data"]
        self.assertEqual(returned["status"], "Returned")
        self.assertEqual(returned["return_date"], TODAY)

        self.assertEqual(self.client.get("/api/books").get_json()["data"][0]["available_copies"], 2)
        self.assertEqual(self.client.get("/api/transactions/active").get_json()["count"], 0)
        # History is kept
        history = self.client.get("/api/transactions", query_string={"status": "returned"}).get_json()
        self.assertEqual(history["count"], 1)
        s = self.stats()
        self.assertEqual((s["available_books"], s["issued_books"]), (2, 0))

    # ---- 6. Double return ------------------------------------------------- #
    def test_06_return_twice_is_rejected(self):
        book, member = self.setup_book_and_member(copies=2)
        txn = self.issue(book["id"], member["id"]).get_json()["data"]
        self.assertEqual(self.client.post("/api/transactions/return", json={"transaction_id": txn["id"]}).status_code, 200)

        r = self.client.post("/api/transactions/return", json={"transaction_id": txn["id"]})
        self.assertEqual(r.status_code, 409)
        self.assertIn("already returned", r.get_json()["error"])
        # Stock did NOT increase a second time
        self.assertEqual(self.client.get("/api/books").get_json()["data"][0]["available_copies"], 2)

        self.assertEqual(self.client.post("/api/transactions/return", json={"transaction_id": 9999}).status_code, 404)
        self.assertEqual(self.client.post("/api/transactions/return", json={}).status_code, 400)

    def test_06b_return_date_before_issue_date(self):
        book, member = self.setup_book_and_member()
        txn = self.issue(book["id"], member["id"]).get_json()["data"]
        r = self.client.post("/api/transactions/return", json={"transaction_id": txn["id"], "return_date": YESTERDAY})
        self.assertEqual(r.status_code, 400)
        self.assertEqual(self.client.get("/api/transactions/active").get_json()["count"], 1)

    # ---- 7. Search nonexistent -------------------------------------------- #
    def test_07_search_nonexistent_book(self):
        self.add_book()
        r = self.client.get("/api/books/search", query_string={"q": "quantum basket weaving"})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["count"], 0)
        self.assertEqual(r.get_json()["data"], [])

    def test_07b_search_is_injection_safe(self):
        self.add_book()
        r = self.client.get("/api/books/search", query_string={"q": "x' OR '1'='1"})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["count"], 0)
        r = self.client.get("/api/books/search", query_string={"q": "%"})
        self.assertEqual(r.get_json()["count"], 0)  # % is treated as plain text
        self.assertEqual(self.client.get("/api/books").get_json()["count"], 1)  # table still intact

    def test_07c_category_filter(self):
        self.add_book(isbn="9780132350884", category="Programming")
        self.add_book(isbn="9780262033848", title="Algorithms", category="Computer Science")
        r = self.client.get("/api/books", query_string={"category": "computer science"}).get_json()
        self.assertEqual(r["count"], 1)
        self.assertEqual(self.client.get("/api/categories").get_json()["data"], ["Computer Science", "Programming"])

    # ---- 8. Duplicates ---------------------------------------------------- #
    def test_08_duplicate_isbn_and_email(self):
        self.assertEqual(self.add_book().status_code, 201)
        dup = self.add_book(isbn="978-0-13-235088-4", title="Other")  # same ISBN, hyphenated
        self.assertEqual(dup.status_code, 409)
        self.assertIn("isbn", dup.get_json()["errors"])

        self.assertEqual(self.add_member().status_code, 201)
        dup = self.add_member(email="ASHA@Example.com", name="Someone Else")  # same email, different case
        self.assertEqual(dup.status_code, 409)
        self.assertIn("email", dup.get_json()["errors"])

        # Updating onto an existing ISBN / email is also blocked
        b2 = self.add_book(isbn="9780262033848", title="Algorithms").get_json()["data"]
        r = self.client.put(f"/api/books/{b2['id']}", json={
            "title": "Algorithms", "author": "CLRS", "isbn": "9780132350884",
            "category": "CS", "total_copies": 2})
        self.assertEqual(r.status_code, 409)
        m2 = self.add_member(email="ravi@example.com", name="Ravi Kumar").get_json()["data"]
        r = self.client.put(f"/api/members/{m2['id']}", json={
            "name": "Ravi Kumar", "email": "asha@example.com", "phone": "9876543210"})
        self.assertEqual(r.status_code, 409)

    # ---- 9. Delete blocked ------------------------------------------------ #
    def test_09_delete_with_active_issue_is_blocked(self):
        book, member = self.setup_book_and_member(copies=2)
        txn = self.issue(book["id"], member["id"]).get_json()["data"]

        r = self.client.delete(f"/api/books/{book['id']}")
        self.assertEqual(r.status_code, 409)
        self.assertIn("issued", r.get_json()["error"])
        r = self.client.delete(f"/api/members/{member['id']}")
        self.assertEqual(r.status_code, 409)
        self.assertIn("issued", r.get_json()["error"])

        # After returning, history still protects the rows (foreign keys + records)
        self.client.post("/api/transactions/return", json={"transaction_id": txn["id"]})
        self.assertEqual(self.client.delete(f"/api/books/{book['id']}").status_code, 409)
        self.assertEqual(self.client.delete(f"/api/members/{member['id']}").status_code, 409)
        self.assertEqual(self.client.get("/api/transactions").get_json()["count"], 1)

    def test_09b_reduce_copies_below_issued_is_blocked(self):
        book, member = self.setup_book_and_member(copies=3)
        self.issue(book["id"], member["id"])
        self.issue(book["id"], member["id"])
        r = self.client.put(f"/api/books/{book['id']}", json={
            "title": "Clean Code", "author": "Robert C. Martin", "isbn": "9780132350884",
            "category": "Programming", "total_copies": 1})
        self.assertEqual(r.status_code, 409)
        r = self.client.put(f"/api/books/{book['id']}", json={
            "title": "Clean Code", "author": "Robert C. Martin", "isbn": "9780132350884",
            "category": "Programming", "total_copies": 5})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["data"]["available_copies"], 3)  # 5 total - 2 issued

    def test_09c_missing_records(self):
        self.assertEqual(self.client.delete("/api/books/999").status_code, 404)
        self.assertEqual(self.client.delete("/api/members/999").status_code, 404)
        self.assertEqual(self.client.put("/api/books/999", json={
            "title": "T", "author": "A", "isbn": "9780132350884", "category": "X", "total_copies": 1}).status_code, 404)
        self.assertEqual(self.client.put("/api/members/999", json={
            "name": "Asha", "email": "a@b.com", "phone": "9876543210"}).status_code, 404)
        r = self.client.get("/api/does-not-exist")
        self.assertEqual(r.status_code, 404)
        self.assertFalse(r.get_json()["success"])
        self.assertEqual(self.client.patch("/api/books").status_code, 405)

    # ---- 10. Stats after every operation ---------------------------------- #
    def test_10_stats_track_every_operation(self):
        s = self.stats()
        self.assertEqual((s["total_books"], s["available_books"], s["issued_books"], s["total_members"]), (0, 0, 0, 0))

        book, member = self.setup_book_and_member(copies=3)
        s = self.stats()
        self.assertEqual((s["total_books"], s["total_copies"], s["available_books"], s["issued_books"], s["total_members"]),
                         (1, 3, 3, 0, 1))

        t1 = self.issue(book["id"], member["id"]).get_json()["data"]
        t2 = self.issue(book["id"], member["id"]).get_json()["data"]
        s = self.stats()
        self.assertEqual((s["available_books"], s["issued_books"]), (1, 2))

        self.client.post("/api/transactions/return", json={"transaction_id": t1["id"]})
        s = self.stats()
        self.assertEqual((s["available_books"], s["issued_books"]), (2, 1))

        self.client.post("/api/transactions/return", json={"transaction_id": t2["id"]})
        s = self.stats()
        self.assertEqual((s["available_books"], s["issued_books"]), (3, 0))
        self.assertEqual(s["available_books"] + s["issued_books"], s["total_copies"])

    def test_10b_overdue_is_reported(self):
        book, member = self.setup_book_and_member()
        old_issue = (date.today() - timedelta(days=20)).isoformat()
        old_due = (date.today() - timedelta(days=6)).isoformat()
        r = self.issue(book["id"], member["id"], due=old_due, issue=old_issue)
        self.assertEqual(r.status_code, 201)
        self.assertTrue(r.get_json()["data"]["is_overdue"])
        self.assertEqual(self.stats()["overdue_books"], 1)

    # ---- Database-level guarantees ---------------------------------------- #
    def test_11_foreign_keys_and_checks_are_enforced_by_sqlite(self):
        conn = connect()
        try:
            self.assertEqual(conn.execute("PRAGMA foreign_keys").fetchone()[0], 1)
            with self.assertRaises(sqlite3.IntegrityError):
                conn.execute(
                    "INSERT INTO transactions (book_id, member_id, issue_date, due_date) "
                    "VALUES (999, 999, '2030-01-01', '2030-01-10')")
            with self.assertRaises(sqlite3.IntegrityError):
                conn.execute(
                    "INSERT INTO books (title, author, isbn, category, total_copies, available_copies) "
                    "VALUES ('T', 'A', '1', 'C', 1, -1)")
        finally:
            conn.close()

    def test_12_sample_data_seeds_consistently(self):
        reset_db()
        s = self.stats()
        self.assertGreater(s["total_books"], 0)
        self.assertGreater(s["total_members"], 0)
        self.assertEqual(s["available_books"] + s["issued_books"], s["total_copies"])
        self.assertGreaterEqual(s["overdue_books"], 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)

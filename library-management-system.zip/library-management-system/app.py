"""
app.py - Flask REST API for the Library Management System.

Layers (kept separate on purpose, easy to explain in a viva):
  frontend/     HTML + CSS + JavaScript   -> what the user sees
  app.py        Flask routes (this file)  -> business rules + JSON responses
  database.py   SQLite helpers            -> connections, schema, transactions

Every API response uses one of these JSON shapes:
  success: {"success": true,  "message": "...", "data": ...}
  failure: {"success": false, "error": "...", "errors": {"field": "..."}}
"""

import os
import re
import sqlite3

from flask import Flask, jsonify, request, send_from_directory

from database import close_db, get_db, init_db, transaction
from validators import (
    ValidationError,
    today_iso,
    validate_book,
    validate_issue,
    validate_member,
    validate_return,
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.join(BASE_DIR, "frontend")

app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path="/static")
app.json.sort_keys = False
app.teardown_appcontext(close_db)


# --------------------------------------------------------------------------- #
# Helpers: responses and errors
# --------------------------------------------------------------------------- #
class ApiError(Exception):
    """An expected problem (bad input, missing record, conflict...)."""

    def __init__(self, message, status=400, errors=None):
        super().__init__(message)
        self.message = message
        self.status = status
        self.errors = errors or {}


def ok(data=None, message="OK", status=200, **extra):
    body = {"success": True, "message": message, "data": data}
    body.update(extra)
    return jsonify(body), status


def fail(message, status=400, errors=None):
    return jsonify({"success": False, "error": message, "errors": errors or {}}), status


def json_body():
    """Return the request JSON as a dict, or raise a 400 if it is missing/invalid."""
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        raise ApiError("Request body must be a JSON object.", 400)
    return data


@app.errorhandler(ApiError)
def handle_api_error(error):
    return fail(error.message, error.status, error.errors)


@app.errorhandler(ValidationError)
def handle_validation_error(error):
    first = next(iter(error.errors.values()))
    return fail(f"Please fix the highlighted fields. {first}", 400, error.errors)


@app.errorhandler(sqlite3.IntegrityError)
def handle_integrity_error(error):
    # Last line of defence if a rule slipped past our own checks (e.g. two
    # people saving the same ISBN at the very same moment).
    app.logger.exception("Database integrity error")
    text = str(error)
    if "books.isbn" in text:
        return fail("A book with this ISBN already exists.", 409, {"isbn": "This ISBN is already in use."})
    if "members.email" in text:
        return fail("A member with this email already exists.", 409, {"email": "This email is already registered."})
    return fail("The database rejected this change because it would break a data rule.", 409)


@app.errorhandler(sqlite3.Error)
def handle_database_error(error):
    app.logger.exception("Database error")
    return fail("A database error occurred. Please try again.", 500)


@app.errorhandler(404)
def handle_not_found(_error):
    if request.path.startswith("/api/"):
        return fail("This API endpoint does not exist.", 404)
    return "Page not found", 404


@app.errorhandler(405)
def handle_method_not_allowed(_error):
    return fail("This HTTP method is not allowed for this endpoint.", 405)


@app.errorhandler(Exception)
def handle_unexpected_error(error):
    # Flask's own HTTP errors (404, 405...) keep their normal handling.
    from werkzeug.exceptions import HTTPException

    if isinstance(error, HTTPException):
        return error
    app.logger.exception("Unexpected server error")
    return fail("Unexpected server error. Check the terminal running Flask for details.", 500)


def like_pattern(text):
    """Turn user text into a safe LIKE pattern (escape % and _)."""
    escaped = text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{escaped}%"


# --------------------------------------------------------------------------- #
# Row -> dict converters
# --------------------------------------------------------------------------- #
def book_to_dict(row):
    book = dict(row)
    book["issued_copies"] = book["total_copies"] - book["available_copies"]
    book["availability"] = "Available" if book["available_copies"] > 0 else "Unavailable"
    return book


def transaction_to_dict(row):
    item = dict(row)
    item["is_overdue"] = item["status"] == "Issued" and item["due_date"] < today_iso()
    return item


TRANSACTION_SELECT = """
    SELECT t.id, t.book_id, t.member_id,
           b.title AS book_title, b.isbn AS book_isbn,
           m.name  AS member_name,
           t.issue_date, t.due_date, t.return_date, t.status
    FROM transactions t
    JOIN books   b ON b.id = t.book_id
    JOIN members m ON m.id = t.member_id
"""


# --------------------------------------------------------------------------- #
# Frontend (served by Flask so fetch() calls share the same origin)
# --------------------------------------------------------------------------- #
@app.get("/")
def home():
    return send_from_directory(FRONTEND_DIR, "index.html")


# --------------------------------------------------------------------------- #
# Books
# --------------------------------------------------------------------------- #
def search_books(db, q="", category="", availability=""):
    sql = "SELECT * FROM books WHERE 1 = 1"
    params = []

    q = (q or "").strip()
    if q:
        pattern = like_pattern(q)
        isbn_pattern = like_pattern(re.sub(r"[\s-]", "", q))  # allow typing hyphens
        sql += (
            " AND (title LIKE ? ESCAPE '\\' OR author LIKE ? ESCAPE '\\'"
            " OR isbn LIKE ? ESCAPE '\\' OR isbn LIKE ? ESCAPE '\\' OR category LIKE ? ESCAPE '\\')"
        )
        params += [pattern, pattern, pattern, isbn_pattern, pattern]

    category = (category or "").strip()
    if category:
        sql += " AND category = ? COLLATE NOCASE"
        params.append(category)

    availability = (availability or "").strip().lower()
    if availability == "available":
        sql += " AND available_copies > 0"
    elif availability == "unavailable":
        sql += " AND available_copies = 0"
    elif availability:
        raise ApiError("availability must be 'available' or 'unavailable'.", 400)

    sql += " ORDER BY title COLLATE NOCASE"
    return [book_to_dict(r) for r in db.execute(sql, params).fetchall()]


@app.get("/api/books")
def list_books():
    books = search_books(
        get_db(),
        request.args.get("q", ""),
        request.args.get("category", ""),
        request.args.get("availability", ""),
    )
    return ok(books, "Books loaded.", count=len(books))


@app.get("/api/books/search")
def search_books_route():
    books = search_books(
        get_db(),
        request.args.get("q", ""),
        request.args.get("category", ""),
        request.args.get("availability", ""),
    )
    return ok(books, f"{len(books)} book(s) found.", count=len(books))


@app.get("/api/categories")
def list_categories():
    rows = get_db().execute("SELECT DISTINCT category FROM books ORDER BY category COLLATE NOCASE").fetchall()
    return ok([r["category"] for r in rows], "Categories loaded.")


@app.post("/api/books")
def add_book():
    clean = validate_book(json_body())
    db = get_db()
    if db.execute("SELECT 1 FROM books WHERE isbn = ?", (clean["isbn"],)).fetchone():
        raise ApiError("A book with this ISBN already exists.", 409, {"isbn": "This ISBN is already in use."})

    cur = db.execute(
        "INSERT INTO books (title, author, isbn, category, total_copies, available_copies) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (clean["title"], clean["author"], clean["isbn"], clean["category"],
         clean["total_copies"], clean["total_copies"]),
    )
    row = db.execute("SELECT * FROM books WHERE id = ?", (cur.lastrowid,)).fetchone()
    return ok(book_to_dict(row), f"'{clean['title']}' was added to the library.", 201)


@app.put("/api/books/<int:book_id>")
def update_book(book_id):
    clean = validate_book(json_body())
    db = get_db()
    with transaction(db):
        book = db.execute("SELECT * FROM books WHERE id = ?", (book_id,)).fetchone()
        if not book:
            raise ApiError("Book not found.", 404)

        clash = db.execute(
            "SELECT 1 FROM books WHERE isbn = ? AND id <> ?", (clean["isbn"], book_id)
        ).fetchone()
        if clash:
            raise ApiError("Another book already uses this ISBN.", 409, {"isbn": "This ISBN is already in use."})

        # Copies that are currently out on loan must still be accounted for.
        issued = book["total_copies"] - book["available_copies"]
        if clean["total_copies"] < issued:
            raise ApiError(
                f"Total copies cannot be less than the {issued} copy(ies) currently issued.",
                409,
                {"total_copies": f"At least {issued} needed (currently issued)."},
            )

        db.execute(
            "UPDATE books SET title = ?, author = ?, isbn = ?, category = ?, "
            "total_copies = ?, available_copies = ? WHERE id = ?",
            (clean["title"], clean["author"], clean["isbn"], clean["category"],
             clean["total_copies"], clean["total_copies"] - issued, book_id),
        )
    row = db.execute("SELECT * FROM books WHERE id = ?", (book_id,)).fetchone()
    return ok(book_to_dict(row), f"'{clean['title']}' was updated.")


@app.delete("/api/books/<int:book_id>")
def delete_book(book_id):
    db = get_db()
    with transaction(db):
        book = db.execute("SELECT * FROM books WHERE id = ?", (book_id,)).fetchone()
        if not book:
            raise ApiError("Book not found.", 404)

        active = db.execute(
            "SELECT COUNT(*) FROM transactions WHERE book_id = ? AND status = 'Issued'", (book_id,)
        ).fetchone()[0]
        if active:
            raise ApiError(
                f"'{book['title']}' cannot be deleted while {active} copy(ies) are issued. Return them first.",
                409,
            )

        history = db.execute("SELECT COUNT(*) FROM transactions WHERE book_id = ?", (book_id,)).fetchone()[0]
        if history:
            raise ApiError(
                f"'{book['title']}' has {history} past transaction(s). Its history is kept for records, "
                "so the book cannot be deleted.",
                409,
            )

        db.execute("DELETE FROM books WHERE id = ?", (book_id,))
    return ok({"id": book_id}, f"'{book['title']}' was deleted.")


# --------------------------------------------------------------------------- #
# Members
# --------------------------------------------------------------------------- #
@app.get("/api/members")
def list_members():
    q = request.args.get("q", "").strip()
    sql = "SELECT * FROM members WHERE 1 = 1"
    params = []
    if q:
        pattern = like_pattern(q)
        sql += (
            " AND (name LIKE ? ESCAPE '\\' OR email LIKE ? ESCAPE '\\'"
            " OR CAST(id AS TEXT) LIKE ? ESCAPE '\\')"
        )
        params += [pattern, pattern, pattern]
    sql += " ORDER BY name COLLATE NOCASE"
    members = [dict(r) for r in get_db().execute(sql, params).fetchall()]
    return ok(members, "Members loaded.", count=len(members))


@app.post("/api/members")
def add_member():
    clean = validate_member(json_body(), creating=True)
    db = get_db()
    if db.execute("SELECT 1 FROM members WHERE email = ?", (clean["email"],)).fetchone():
        raise ApiError("A member with this email already exists.", 409, {"email": "This email is already registered."})

    cur = db.execute(
        "INSERT INTO members (name, email, phone, registration_date) VALUES (?, ?, ?, ?)",
        (clean["name"], clean["email"], clean["phone"], clean["registration_date"]),
    )
    row = db.execute("SELECT * FROM members WHERE id = ?", (cur.lastrowid,)).fetchone()
    return ok(dict(row), f"{clean['name']} was registered as a member.", 201)


@app.put("/api/members/<int:member_id>")
def update_member(member_id):
    clean = validate_member(json_body(), creating=False)
    db = get_db()
    with transaction(db):
        if not db.execute("SELECT 1 FROM members WHERE id = ?", (member_id,)).fetchone():
            raise ApiError("Member not found.", 404)
        clash = db.execute(
            "SELECT 1 FROM members WHERE email = ? AND id <> ?", (clean["email"], member_id)
        ).fetchone()
        if clash:
            raise ApiError("Another member already uses this email.", 409, {"email": "This email is already registered."})
        db.execute(
            "UPDATE members SET name = ?, email = ?, phone = ? WHERE id = ?",
            (clean["name"], clean["email"], clean["phone"], member_id),
        )
    row = db.execute("SELECT * FROM members WHERE id = ?", (member_id,)).fetchone()
    return ok(dict(row), f"{clean['name']}'s details were updated.")


@app.delete("/api/members/<int:member_id>")
def delete_member(member_id):
    db = get_db()
    with transaction(db):
        member = db.execute("SELECT * FROM members WHERE id = ?", (member_id,)).fetchone()
        if not member:
            raise ApiError("Member not found.", 404)

        active = db.execute(
            "SELECT COUNT(*) FROM transactions WHERE member_id = ? AND status = 'Issued'", (member_id,)
        ).fetchone()[0]
        if active:
            raise ApiError(
                f"{member['name']} still has {active} book(s) issued. Return them before deleting this member.",
                409,
            )

        history = db.execute("SELECT COUNT(*) FROM transactions WHERE member_id = ?", (member_id,)).fetchone()[0]
        if history:
            raise ApiError(
                f"{member['name']} has {history} past transaction(s). Their history is kept for records, "
                "so the member cannot be deleted.",
                409,
            )

        db.execute("DELETE FROM members WHERE id = ?", (member_id,))
    return ok({"id": member_id}, f"{member['name']} was removed from the members list.")


# --------------------------------------------------------------------------- #
# Issue / return / history
# --------------------------------------------------------------------------- #
@app.post("/api/transactions/issue")
def issue_book():
    clean = validate_issue(json_body())
    db = get_db()

    # One all-or-nothing unit: stock goes down AND the transaction is recorded,
    # or neither happens.
    with transaction(db):
        member = db.execute("SELECT * FROM members WHERE id = ?", (clean["member_id"],)).fetchone()
        if not member:
            raise ApiError("Member not found. Register the member first.", 404, {"member_id": "Select a registered member."})

        book = db.execute("SELECT * FROM books WHERE id = ?", (clean["book_id"],)).fetchone()
        if not book:
            raise ApiError("Book not found.", 404, {"book_id": "Select a book from the list."})

        # The "AND available_copies > 0" condition makes the check and the
        # decrement a single atomic step, so stock can never go negative.
        updated = db.execute(
            "UPDATE books SET available_copies = available_copies - 1 "
            "WHERE id = ? AND available_copies > 0",
            (clean["book_id"],),
        )
        if updated.rowcount == 0:
            raise ApiError(
                f"No copies of '{book['title']}' are available right now.",
                409,
                {"book_id": "No copies available."},
            )

        cur = db.execute(
            "INSERT INTO transactions (book_id, member_id, issue_date, due_date, return_date, status) "
            "VALUES (?, ?, ?, ?, NULL, 'Issued')",
            (clean["book_id"], clean["member_id"], clean["issue_date"], clean["due_date"]),
        )
        transaction_id = cur.lastrowid

    row = db.execute(TRANSACTION_SELECT + " WHERE t.id = ?", (transaction_id,)).fetchone()
    return ok(
        transaction_to_dict(row),
        f"'{book['title']}' was issued to {member['name']}. Due on {clean['due_date']}.",
        201,
    )


@app.post("/api/transactions/return")
def return_book():
    clean = validate_return(json_body())
    db = get_db()

    with transaction(db):
        txn = db.execute("SELECT * FROM transactions WHERE id = ?", (clean["transaction_id"],)).fetchone()
        if not txn:
            raise ApiError("Transaction not found.", 404)

        if txn["status"] != "Issued":
            raise ApiError(
                f"This book was already returned on {txn['return_date']}. It cannot be returned twice.",
                409,
            )

        if clean["return_date"] < txn["issue_date"]:
            raise ApiError(
                "Return date cannot be earlier than the issue date.",
                400,
                {"return_date": f"Must be on or after {txn['issue_date']}."},
            )

        # "AND status = 'Issued'" guarantees only ONE request can win the return.
        updated = db.execute(
            "UPDATE transactions SET return_date = ?, status = 'Returned' "
            "WHERE id = ? AND status = 'Issued'",
            (clean["return_date"], clean["transaction_id"]),
        )
        if updated.rowcount != 1:
            raise ApiError("This book was already returned.", 409)

        # Stock goes up only after a successful, first-time return.
        db.execute(
            "UPDATE books SET available_copies = available_copies + 1 WHERE id = ?",
            (txn["book_id"],),
        )

    row = db.execute(TRANSACTION_SELECT + " WHERE t.id = ?", (clean["transaction_id"],)).fetchone()
    result = transaction_to_dict(row)
    return ok(result, f"'{result['book_title']}' was returned by {result['member_name']}.")


def query_transactions(db, status="", q=""):
    sql = TRANSACTION_SELECT + " WHERE 1 = 1"
    params = []

    status = (status or "").strip().lower()
    if status in ("issued", "active"):
        sql += " AND t.status = 'Issued'"
    elif status == "returned":
        sql += " AND t.status = 'Returned'"
    elif status:
        raise ApiError("status must be 'issued' (or 'active') or 'returned'.", 400)

    q = (q or "").strip()
    if q:
        pattern = like_pattern(q)
        sql += (
            " AND (b.title LIKE ? ESCAPE '\\' OR m.name LIKE ? ESCAPE '\\'"
            " OR CAST(t.id AS TEXT) LIKE ? ESCAPE '\\')"
        )
        params += [pattern, pattern, pattern]

    sql += " ORDER BY t.id DESC"
    return [transaction_to_dict(r) for r in db.execute(sql, params).fetchall()]


@app.get("/api/transactions")
def list_transactions():
    items = query_transactions(get_db(), request.args.get("status", ""), request.args.get("q", ""))
    return ok(items, "Transactions loaded.", count=len(items))


@app.get("/api/transactions/active")
def list_active_transactions():
    items = query_transactions(get_db(), "issued", request.args.get("q", ""))
    items.sort(key=lambda t: (t["due_date"], t["id"]))  # most urgent first
    return ok(items, "Active issues loaded.", count=len(items))


# --------------------------------------------------------------------------- #
# Dashboard
# --------------------------------------------------------------------------- #
@app.get("/api/dashboard/stats")
def dashboard_stats():
    db = get_db()
    totals = db.execute(
        "SELECT COUNT(*) AS titles, COALESCE(SUM(total_copies), 0) AS copies, "
        "COALESCE(SUM(available_copies), 0) AS available FROM books"
    ).fetchone()
    members = db.execute("SELECT COUNT(*) FROM members").fetchone()[0]
    issued = db.execute("SELECT COUNT(*) FROM transactions WHERE status = 'Issued'").fetchone()[0]
    overdue = db.execute(
        "SELECT COUNT(*) FROM transactions WHERE status = 'Issued' AND due_date < ?", (today_iso(),)
    ).fetchone()[0]

    recent_books = [
        book_to_dict(r)
        for r in db.execute("SELECT * FROM books ORDER BY id DESC LIMIT 5").fetchall()
    ]
    recent_transactions = [
        transaction_to_dict(r)
        for r in db.execute(TRANSACTION_SELECT + " ORDER BY t.id DESC LIMIT 6").fetchall()
    ]

    stats = {
        "total_books": totals["titles"],
        "total_copies": totals["copies"],
        "available_books": totals["available"],
        "issued_books": issued,
        "total_members": members,
        "overdue_books": overdue,
        "recent_books": recent_books,
        "recent_transactions": recent_transactions,
    }
    return ok(stats, "Dashboard statistics loaded.")


# --------------------------------------------------------------------------- #
# Start-up
# --------------------------------------------------------------------------- #
# Create tables (and demo data on first run) whenever the app is imported/started.
init_db()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    print(f"\n  Library Management System running at http://127.0.0.1:{port}\n")
    app.run(host="127.0.0.1", port=port, debug=True)

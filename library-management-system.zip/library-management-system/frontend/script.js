/* ==========================================================================
   Library Management System - frontend logic (vanilla JavaScript)

   How this file is organised
     1. Helpers          (DOM shortcuts, dates, escaping, icons)
     2. API layer        (one place that talks to Flask using fetch)
     3. UI building blocks (toasts, dialogs, form errors, loading/empty states)
     4. Views            (dashboard, books, members, issue/return, transactions)
     5. Start-up         (navigation + first page load)
   ========================================================================== */
'use strict';

/* ------------------------------ 1. Helpers ------------------------------ */
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

const ICONS = {
  dashboard: '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>',
  book: '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
  users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  repeat: '<polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/>',
  list: '<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>',
  plus: '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
  search: '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
  edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/>',
  trash: '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>',
  x: '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
  menu: '<line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/>',
  check: '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>',
  alert: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>',
  inbox: '<polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
  undo: '<polyline points="9 10 4 15 9 20"/><path d="M20 4v7a4 4 0 0 1-4 4H4"/>',
};

function icon(name, size = 18) {
  return `<svg class="icon" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${ICONS[name] || ''}</svg>`;
}

/** Escape text before putting it inside HTML (prevents script injection). */
function esc(value) {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return String(value ?? '').replace(/[&<>"']/g, (c) => map[c]);
}

function plural(count, one, many) {
  return count === 1 ? one : many;
}

function toISODate(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}
const todayISO = () => toISODate(new Date());

function addDays(iso, days) {
  const d = new Date(`${iso}T00:00:00`);
  d.setDate(d.getDate() + days);
  return toISODate(d);
}

function fmtDate(iso) {
  if (!iso) return '-';
  const d = new Date(`${iso}T00:00:00`);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

function debounce(fn, wait = 250) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), wait);
  };
}

const SPINE_COLORS = ['#1d3a73', '#2b948d', '#6f86b3', '#b9852d', '#7b5a82', '#4f7f9a'];
function spineColor(category) {
  let hash = 0;
  for (const ch of String(category).toLowerCase()) hash = (hash * 31 + ch.charCodeAt(0)) >>> 0;
  return SPINE_COLORS[hash % SPINE_COLORS.length];
}

/* ------------------------------ 2. API layer ------------------------------ */
class ApiFailure extends Error {
  constructor(message, status = 0, errors = {}) {
    super(message);
    this.name = 'ApiFailure';
    this.status = status;
    this.errors = errors;
  }
}

/**
 * Wrapper around fetch(). Sends/receives JSON and turns every kind of failure
 * (network down, 400/404/409/500 from Flask) into an ApiFailure with a
 * readable message.
 */
async function api(path, { method = 'GET', body, signal } = {}) {
  const options = { method, headers: { Accept: 'application/json' }, signal };
  if (body !== undefined) {
    options.headers['Content-Type'] = 'application/json';
    options.body = JSON.stringify(body);
  }

  let response;
  try {
    response = await fetch(path, options);
  } catch (error) {
    if (error.name === 'AbortError') throw error;
    throw new ApiFailure('Cannot reach the server. Check that Flask is still running, then try again.');
  }

  let payload = null;
  try {
    payload = await response.json();
  } catch (_ignored) {
    /* the server did not send JSON; handled just below */
  }

  if (!response.ok || !payload || payload.success === false) {
    const message = (payload && payload.error) || `The server returned an unexpected response (${response.status}).`;
    throw new ApiFailure(message, response.status, (payload && payload.errors) || {});
  }
  return payload;
}

/** Keeps only the newest request of a kind alive (important for live search). */
function createRequestGate() {
  let seq = 0;
  let controller = null;
  return {
    start() {
      if (controller) controller.abort();
      controller = new AbortController();
      seq += 1;
      return { id: seq, signal: controller.signal };
    },
    isLatest(id) {
      return id === seq;
    },
  };
}

/* ------------------------------ 3. UI building blocks ------------------------------ */
function toast(message, type = 'success') {
  const el = document.createElement('div');
  el.className = `toast ${type === 'error' ? 'error' : ''}`;
  el.innerHTML = `
    <span class="toast-icon">${icon(type === 'error' ? 'alert' : 'check', 20)}</span>
    <p>${esc(message)}</p>
    <button type="button" class="icon-btn" aria-label="Dismiss message">${icon('x', 16)}</button>`;
  const remove = () => el.remove();
  $('button', el).addEventListener('click', remove);
  $('#toasts').appendChild(el);
  setTimeout(remove, type === 'error' ? 9000 : 5000);
}

function reportError(error) {
  if (error instanceof ApiFailure) {
    toast(error.message, 'error');
  } else {
    console.error(error);
    toast('Something went wrong in the page. Open the browser console for details.', 'error');
  }
}

/* ---- loading / empty / error blocks ---- */
function loadingBlock(label = 'Loading') {
  const rows = '<div class="skeleton-row"></div>'.repeat(4);
  return `<div class="loading-label" role="status"><span class="spinner"></span>${esc(label)}...</div>
          <div class="skeleton" aria-hidden="true">${rows}</div>`;
}

function emptyBlock({ title, text, action = '' }) {
  return `<div class="state"><span class="state-icon">${icon('inbox', 40)}</span>
          <h3>${esc(title)}</h3><p>${esc(text)}</p>${action}</div>`;
}

function errorBlock(message, retryView) {
  return `<div class="state state-error" role="alert"><span class="state-icon">${icon('alert', 40)}</span>
          <h3>This data could not be loaded</h3><p>${esc(message)}</p>
          <button type="button" class="btn btn-ghost" data-retry="${esc(retryView)}">Try again</button></div>`;
}

/** Fetch a list into a container with loading, error and re-render handling. */
async function fetchInto({ gate, container, label, url, retryView, render }) {
  const request = gate.start();
  if ($('table', container)) container.classList.add('is-busy');
  else container.innerHTML = loadingBlock(label);

  try {
    const response = await api(url, { signal: request.signal });
    if (!gate.isLatest(request.id)) return null;
    render(response);
    return response;
  } catch (error) {
    if (error.name === 'AbortError' || !gate.isLatest(request.id)) return null;
    if (!(error instanceof ApiFailure)) console.error(error);
    container.innerHTML = errorBlock(
      error instanceof ApiFailure ? error.message : 'The page could not display this data.',
      retryView
    );
    return null;
  } finally {
    if (gate.isLatest(request.id)) container.classList.remove('is-busy');
  }
}

/* ---- badges ---- */
function availabilityBadge(book) {
  return book.available_copies > 0
    ? '<span class="badge badge-available">Available</span>'
    : '<span class="badge badge-unavailable">Unavailable</span>';
}

function transactionBadge(txn) {
  if (txn.status === 'Returned') return '<span class="badge badge-returned">Returned</span>';
  if (txn.is_overdue) return '<span class="badge badge-overdue">Overdue</span>';
  return '<span class="badge badge-issued">Issued</span>';
}

/* ---- dialogs ---- */
function openDialog(dialog) {
  if (!dialog.open) dialog.showModal();
}

$$('dialog').forEach((dialog) => {
  // click on the dark backdrop closes the dialog
  dialog.addEventListener('click', (event) => {
    if (event.target === dialog) dialog.close();
  });
  $$('[data-close]', dialog).forEach((btn) => btn.addEventListener('click', () => dialog.close()));
});

function confirmAction({ title, message, confirmLabel = 'Confirm', danger = false }) {
  const dialog = $('#confirm-dialog');
  const okButton = $('#confirm-ok');
  $('#confirm-title').textContent = title;
  $('#confirm-message').textContent = message;
  okButton.textContent = confirmLabel;
  okButton.className = `btn ${danger ? 'btn-danger' : 'btn-primary'}`;
  dialog.returnValue = '';

  return new Promise((resolve) => {
    dialog.addEventListener('close', () => resolve(dialog.returnValue === 'confirm'), { once: true });
    openDialog(dialog);
  });
}

/* ---- form errors ---- */
function clearErrors(form) {
  $$('.field', form).forEach((field) => field.classList.remove('invalid'));
  $$('[data-error-for]', form).forEach((p) => { p.textContent = ''; });
  $$('[aria-invalid]', form).forEach((input) => input.removeAttribute('aria-invalid'));
  const banner = $('[data-form-error]', form);
  if (banner) { banner.hidden = true; banner.textContent = ''; }
  const inline = $('.inline-result', form);
  if (inline) { inline.hidden = true; inline.textContent = ''; }
}

function showFormMessage(form, message, kind = 'err') {
  const banner = $('[data-form-error]', form);
  if (banner) {
    banner.textContent = message;
    banner.hidden = false;
    return;
  }
  const inline = $('.inline-result', form);
  if (inline) {
    inline.className = `inline-result ${kind}`;
    inline.textContent = message;
    inline.hidden = false;
  }
}

function showFieldErrors(form, errors) {
  let firstInput = null;
  Object.entries(errors).forEach(([name, message]) => {
    const holder = $(`[data-error-for="${name}"]`, form);
    if (!holder) return;
    holder.textContent = message;
    const field = holder.closest('.field');
    if (field) field.classList.add('invalid');
    const input = form.elements[name];
    if (input) {
      input.setAttribute('aria-invalid', 'true');
      if (!firstInput) firstInput = input;
    }
  });
  if (firstInput) firstInput.focus();
}

/** Disables the button, runs the request, and maps server errors onto the form. */
async function submitForm({ form, button, busyLabel, request, onSuccess }) {
  const originalLabel = button.textContent;
  button.disabled = true;
  button.innerHTML = `<span class="spinner"></span>${esc(busyLabel)}`;
  try {
    const response = await request();
    await onSuccess(response);
  } catch (error) {
    if (error instanceof ApiFailure) {
      showFieldErrors(form, error.errors);
      showFormMessage(form, error.message);
    } else {
      console.error(error);
      showFormMessage(form, 'Something went wrong in the page. Open the browser console for details.');
    }
  } finally {
    button.disabled = false;
    button.textContent = originalLabel;
  }
}

/* ---- client-side validation (the server checks everything again) ---- */
const EMAIL_RE = /^[A-Za-z0-9._%+\-]+@[A-Za-z0-9\-]+(\.[A-Za-z0-9\-]+)*\.[A-Za-z]{2,}$/;

function parseWholeNumber(value) {
  const text = String(value ?? '').trim();
  return /^-?\d+$/.test(text) ? parseInt(text, 10) : null;
}

function validateBook(p) {
  const errors = {};
  if (!p.title) errors.title = 'Title is required.';
  if (!p.author) errors.author = 'Author is required.';
  const isbn = p.isbn.replace(/[\s-]/g, '').toUpperCase();
  if (!p.isbn) errors.isbn = 'ISBN is required.';
  else if (!/^(\d{9}[\dX]|\d{13})$/.test(isbn)) errors.isbn = 'ISBN must have 10 or 13 digits (hyphens are allowed).';
  if (!p.category) errors.category = 'Category is required.';
  if (p.total_copies === null) errors.total_copies = 'Enter the number of copies as a whole number.';
  else if (p.total_copies < 0) errors.total_copies = 'Copies cannot be negative.';
  else if (p.total_copies < 1) errors.total_copies = 'A book needs at least 1 copy.';
  else if (p.total_copies > 10000) errors.total_copies = 'Copies must be 10000 or fewer.';
  return errors;
}

function validateMember(p) {
  const errors = {};
  if (!p.name) errors.name = 'Full name is required.';
  else if (p.name.length < 2) errors.name = 'Full name must be at least 2 characters.';
  if (!p.email) errors.email = 'Email is required.';
  else if (!EMAIL_RE.test(p.email)) errors.email = 'Enter a valid email address, for example name@example.com.';
  const digits = p.phone.replace(/\D/g, '');
  if (!p.phone) errors.phone = 'Phone number is required.';
  else if (!/^[0-9+\-\s()]+$/.test(p.phone) || digits.length < 7 || digits.length > 15) {
    errors.phone = 'Phone number must contain 7 to 15 digits.';
  }
  return errors;
}

/* ------------------------------ 4. Views ------------------------------ */
const state = { books: [], members: [], active: [], categories: [] };
const touched = { bookId: null, memberId: null };

const VIEW_TITLES = {
  dashboard: 'Dashboard',
  books: 'Books',
  members: 'Members',
  issue: 'Issue / Return',
  transactions: 'Transactions',
};

const views = {
  dashboard: { dirty: true, load: () => loadDashboard() },
  books: { dirty: true, load: async () => { await loadCategories(); await loadBooks(); } },
  members: { dirty: true, load: () => loadMembers() },
  issue: { dirty: true, load: () => loadIssueView() },
  transactions: { dirty: true, load: () => loadTransactions() },
};
let currentView = 'dashboard';

/** After any change (add, edit, delete, issue, return) every page needs fresh data. */
function invalidate() {
  Object.values(views).forEach((v) => { v.dirty = true; });
  views[currentView].dirty = false;
  views[currentView].load();
}

/* ============================== Dashboard ============================== */
const dashboardGate = createRequestGate();

async function loadDashboard() {
  await fetchInto({
    gate: dashboardGate,
    container: $('#recent-books'),
    label: 'Loading dashboard',
    url: '/api/dashboard/stats',
    retryView: 'dashboard',
    render: (response) => renderDashboard(response.data),
  });
}

function renderDashboard(stats) {
  $('#stat-total-books').textContent = stats.total_books;
  $('#stat-total-note').textContent = `${stats.total_copies} ${plural(stats.total_copies, 'copy', 'copies')} in total`;
  $('#stat-available').textContent = stats.available_books;
  $('#stat-issued').textContent = stats.issued_books;
  $('#stat-issued-note').textContent = stats.overdue_books > 0
    ? `${stats.overdue_books} overdue`
    : 'copies out on loan';
  $('#stat-members').textContent = stats.total_members;

  const total = stats.total_copies;
  const availablePct = total ? (stats.available_books / total) * 100 : 0;
  $('#seg-available').style.width = `${availablePct}%`;
  $('#seg-issued').style.width = total ? `${100 - availablePct}%` : '0%';
  $('#shelf-caption').textContent = total
    ? `${stats.available_books} of ${total} copies on the shelf`
    : 'No copies yet';
  $('#shelf-bar').setAttribute('aria-label',
    `${stats.available_books} copies on the shelf and ${stats.issued_books} issued, out of ${total}`);

  const banner = $('#overdue-banner');
  if (stats.overdue_books > 0) {
    banner.innerHTML = `${icon('alert', 20)}<span>${stats.overdue_books} ${plural(stats.overdue_books, 'book is', 'books are')} past the due date.</span>
      <a href="#issue">Review issued books</a>`;
    banner.hidden = false;
  } else {
    banner.hidden = true;
  }

  $('#recent-books').innerHTML = stats.recent_books.length
    ? `<ul class="mini-list">${stats.recent_books.map((b) => `
        <li>
          <div class="mini-main"><strong>${esc(b.title)}</strong><span>${esc(b.author)}</span></div>
          ${availabilityBadge(b)}
        </li>`).join('')}</ul>`
    : emptyBlock({ title: 'No books yet', text: 'Books you add will show up here.' });

  $('#recent-transactions').innerHTML = stats.recent_transactions.length
    ? `<ul class="mini-list">${stats.recent_transactions.map((t) => `
        <li>
          <div class="mini-main">
            <strong>${esc(t.book_title)}</strong>
            <span>${esc(t.member_name)}, ${t.status === 'Returned' ? `returned ${fmtDate(t.return_date)}` : `due ${fmtDate(t.due_date)}`}</span>
          </div>
          ${transactionBadge(t)}
        </li>`).join('')}</ul>`
    : emptyBlock({ title: 'No activity yet', text: 'Issued and returned books will show up here.' });
}

/* ============================== Books ============================== */
const booksGate = createRequestGate();

async function loadCategories() {
  try {
    const response = await api('/api/categories');
    state.categories = response.data;
    const select = $('#book-category');
    const current = select.value;
    select.innerHTML = '<option value="">All categories</option>' +
      state.categories.map((c) => `<option value="${esc(c)}">${esc(c)}</option>`).join('');
    select.value = state.categories.includes(current) ? current : '';
    $('#category-options').innerHTML = state.categories.map((c) => `<option value="${esc(c)}"></option>`).join('');
  } catch (error) {
    console.error('Could not load categories', error);
  }
}

function booksQuery() {
  const params = new URLSearchParams();
  const q = $('#book-search').value.trim();
  if (q) params.set('q', q);
  if ($('#book-category').value) params.set('category', $('#book-category').value);
  if ($('#book-availability').value) params.set('availability', $('#book-availability').value);
  return params;
}

async function loadBooks() {
  const params = booksQuery();
  const filtered = params.toString() !== '';
  // Live search uses /api/books/search; the plain list uses /api/books.
  const url = filtered ? `/api/books/search?${params}` : '/api/books';

  await fetchInto({
    gate: booksGate,
    container: $('#books-content'),
    label: 'Loading books',
    url,
    retryView: 'books',
    render: (response) => {
      state.books = response.data;
      renderBooks(filtered);
    },
  });
}

function renderBooks(filtered) {
  const container = $('#books-content');
  const count = state.books.length;
  $('#books-count').textContent = `${count} ${plural(count, 'book', 'books')}${filtered ? ' found' : ' in the catalogue'}`;

  if (count === 0) {
    container.innerHTML = filtered
      ? emptyBlock({
          title: 'No books match your search',
          text: 'Check the spelling or try a shorter keyword. You can also clear the filters.',
          action: '<button type="button" class="btn btn-ghost" data-action="clear-book-filters">Clear filters</button>',
        })
      : emptyBlock({
          title: 'The catalogue is empty',
          text: 'Add the first book to start building the library.',
          action: `<button type="button" class="btn btn-primary" data-action="add-book">${icon('plus', 17)}Add book</button>`,
        });
    return;
  }

  container.innerHTML = `
    <div class="table-scroll"><table>
      <thead><tr>
        <th scope="col">ID</th><th scope="col">Book</th><th scope="col">ISBN</th>
        <th scope="col">Category</th><th scope="col">Copies available</th><th scope="col">Status</th>
        <th scope="col" class="col-actions">Actions</th>
      </tr></thead>
      <tbody>${state.books.map(bookRow).join('')}</tbody>
    </table></div>`;

  if (touched.bookId) {
    const row = $(`tr[data-book-id="${touched.bookId}"]`, container);
    if (row) {
      row.classList.add('flash');
      row.scrollIntoView({ block: 'nearest' });
    }
    touched.bookId = null;
  }
}

function bookRow(book) {
  const title = esc(book.title);
  return `
    <tr class="spine" data-book-id="${book.id}" style="--spine:${spineColor(book.category)}">
      <td data-label="ID">${book.id}</td>
      <td class="cell-main" data-label="Book"><div class="cell-title"><strong>${title}</strong><span>${esc(book.author)}</span></div></td>
      <td data-label="ISBN">${esc(book.isbn)}</td>
      <td data-label="Category"><span class="chip">${esc(book.category)}</span></td>
      <td data-label="Copies available" class="copies"><span><strong>${book.available_copies}</strong> of ${book.total_copies}</span></td>
      <td data-label="Status">${availabilityBadge(book)}</td>
      <td class="cell-actions-td">
        <div class="cell-actions">
          <button type="button" class="btn btn-ghost btn-sm" data-action="issue-book" data-id="${book.id}"
            ${book.available_copies > 0 ? '' : 'disabled'} aria-label="Issue ${title}">Issue</button>
          <button type="button" class="icon-btn" data-action="edit-book" data-id="${book.id}" aria-label="Edit ${title}" title="Edit">${icon('edit')}</button>
          <button type="button" class="icon-btn danger" data-action="delete-book" data-id="${book.id}" aria-label="Delete ${title}" title="Delete">${icon('trash')}</button>
        </div>
      </td>
    </tr>`;
}

const bookDialog = $('#book-dialog');
const bookForm = $('#book-form');

function openBookDialog(book = null) {
  bookForm.reset();
  clearErrors(bookForm);
  bookForm.elements.id.value = book ? book.id : '';
  $('#book-dialog-title').textContent = book ? 'Edit book' : 'Add a book';
  $('#book-submit').textContent = book ? 'Save changes' : 'Add book';
  if (book) {
    bookForm.elements.title.value = book.title;
    bookForm.elements.author.value = book.author;
    bookForm.elements.isbn.value = book.isbn;
    bookForm.elements.category.value = book.category;
    bookForm.elements.total_copies.value = book.total_copies;
  } else {
    bookForm.elements.total_copies.value = 1;
  }
  $('#book-copies-hint').textContent = book && book.issued_copies > 0
    ? `${book.issued_copies} ${plural(book.issued_copies, 'copy is', 'copies are')} currently issued, so the total cannot go below ${book.issued_copies}.`
    : '';
  openDialog(bookDialog);
}

bookForm.addEventListener('submit', (event) => {
  event.preventDefault();
  clearErrors(bookForm);
  const form = bookForm.elements;
  const payload = {
    title: form.title.value.trim(),
    author: form.author.value.trim(),
    isbn: form.isbn.value.trim(),
    category: form.category.value.trim(),
    total_copies: parseWholeNumber(form.total_copies.value),
  };
  const errors = validateBook(payload);
  if (Object.keys(errors).length) {
    showFieldErrors(bookForm, errors);
    return;
  }

  const id = form.id.value;
  submitForm({
    form: bookForm,
    button: $('#book-submit'),
    busyLabel: 'Saving',
    request: () => api(id ? `/api/books/${id}` : '/api/books', { method: id ? 'PUT' : 'POST', body: payload }),
    onSuccess: (response) => {
      touched.bookId = response.data.id;
      bookDialog.close();
      toast(response.message);
      invalidate();
    },
  });
});

async function deleteBook(book) {
  const confirmed = await confirmAction({
    title: 'Delete this book?',
    message: `"${book.title}" will be removed from the catalogue. This cannot be undone.`,
    confirmLabel: 'Delete book',
    danger: true,
  });
  if (!confirmed) return;
  try {
    const response = await api(`/api/books/${book.id}`, { method: 'DELETE' });
    toast(response.message);
    invalidate();
  } catch (error) {
    reportError(error);
  }
}

$('#books-content').addEventListener('click', (event) => {
  const button = event.target.closest('[data-action]');
  if (!button) return;
  const book = state.books.find((b) => b.id === Number(button.dataset.id));
  switch (button.dataset.action) {
    case 'edit-book': if (book) openBookDialog(book); break;
    case 'delete-book': if (book) deleteBook(book); break;
    case 'issue-book':
      if (book) { pendingIssueBookId = book.id; location.hash = '#issue'; }
      break;
    case 'add-book': openBookDialog(); break;
    case 'clear-book-filters':
      $('#book-search').value = '';
      $('#book-category').value = '';
      $('#book-availability').value = '';
      loadBooks();
      break;
    default: break;
  }
});

$('#add-book-btn').addEventListener('click', () => openBookDialog());
$('#book-search').addEventListener('input', debounce(loadBooks, 250));
$('#book-category').addEventListener('change', loadBooks);
$('#book-availability').addEventListener('change', loadBooks);

/* ============================== Members ============================== */
const membersGate = createRequestGate();

async function loadMembers() {
  const q = $('#member-search').value.trim();
  const url = q ? `/api/members?q=${encodeURIComponent(q)}` : '/api/members';
  await fetchInto({
    gate: membersGate,
    container: $('#members-content'),
    label: 'Loading members',
    url,
    retryView: 'members',
    render: (response) => {
      state.members = response.data;
      renderMembers(Boolean(q));
    },
  });
}

function renderMembers(filtered) {
  const container = $('#members-content');
  const count = state.members.length;
  $('#members-count').textContent = `${count} ${plural(count, 'member', 'members')}${filtered ? ' found' : ' registered'}`;

  if (count === 0) {
    container.innerHTML = filtered
      ? emptyBlock({
          title: 'No members match your search',
          text: 'Try a different name, email or member ID.',
          action: '<button type="button" class="btn btn-ghost" data-action="clear-member-search">Clear search</button>',
        })
      : emptyBlock({
          title: 'No members yet',
          text: 'Register a member so they can borrow books.',
          action: `<button type="button" class="btn btn-primary" data-action="add-member">${icon('plus', 17)}Add member</button>`,
        });
    return;
  }

  container.innerHTML = `
    <div class="table-scroll"><table>
      <thead><tr>
        <th scope="col">Member ID</th><th scope="col">Full name</th><th scope="col">Email</th>
        <th scope="col">Phone</th><th scope="col">Registered</th><th scope="col" class="col-actions">Actions</th>
      </tr></thead>
      <tbody>${state.members.map(memberRow).join('')}</tbody>
    </table></div>`;

  if (touched.memberId) {
    const row = $(`tr[data-member-id="${touched.memberId}"]`, container);
    if (row) {
      row.classList.add('flash');
      row.scrollIntoView({ block: 'nearest' });
    }
    touched.memberId = null;
  }
}

function memberRow(member) {
  const name = esc(member.name);
  return `
    <tr data-member-id="${member.id}">
      <td data-label="Member ID">${member.id}</td>
      <td class="cell-main" data-label="Full name"><div class="cell-title"><strong>${name}</strong></div></td>
      <td data-label="Email">${esc(member.email)}</td>
      <td data-label="Phone">${esc(member.phone)}</td>
      <td data-label="Registered">${fmtDate(member.registration_date)}</td>
      <td class="cell-actions-td">
        <div class="cell-actions">
          <button type="button" class="icon-btn" data-action="edit-member" data-id="${member.id}" aria-label="Edit ${name}" title="Edit">${icon('edit')}</button>
          <button type="button" class="icon-btn danger" data-action="delete-member" data-id="${member.id}" aria-label="Delete ${name}" title="Delete">${icon('trash')}</button>
        </div>
      </td>
    </tr>`;
}

const memberDialog = $('#member-dialog');
const memberForm = $('#member-form');

function openMemberDialog(member = null) {
  memberForm.reset();
  clearErrors(memberForm);
  memberForm.elements.id.value = member ? member.id : '';
  $('#member-dialog-title').textContent = member ? 'Edit member' : 'Add a member';
  $('#member-submit').textContent = member ? 'Save changes' : 'Add member';
  if (member) {
    memberForm.elements.name.value = member.name;
    memberForm.elements.email.value = member.email;
    memberForm.elements.phone.value = member.phone;
  }
  openDialog(memberDialog);
}

memberForm.addEventListener('submit', (event) => {
  event.preventDefault();
  clearErrors(memberForm);
  const form = memberForm.elements;
  const payload = {
    name: form.name.value.trim(),
    email: form.email.value.trim().toLowerCase(),
    phone: form.phone.value.trim(),
  };
  const errors = validateMember(payload);
  if (Object.keys(errors).length) {
    showFieldErrors(memberForm, errors);
    return;
  }

  const id = form.id.value;
  submitForm({
    form: memberForm,
    button: $('#member-submit'),
    busyLabel: 'Saving',
    request: () => api(id ? `/api/members/${id}` : '/api/members', { method: id ? 'PUT' : 'POST', body: payload }),
    onSuccess: (response) => {
      touched.memberId = response.data.id;
      memberDialog.close();
      toast(response.message);
      invalidate();
    },
  });
});

async function deleteMember(member) {
  const confirmed = await confirmAction({
    title: 'Delete this member?',
    message: `${member.name} will be removed from the members list. This cannot be undone.`,
    confirmLabel: 'Delete member',
    danger: true,
  });
  if (!confirmed) return;
  try {
    const response = await api(`/api/members/${member.id}`, { method: 'DELETE' });
    toast(response.message);
    invalidate();
  } catch (error) {
    reportError(error);
  }
}

$('#members-content').addEventListener('click', (event) => {
  const button = event.target.closest('[data-action]');
  if (!button) return;
  const member = state.members.find((m) => m.id === Number(button.dataset.id));
  switch (button.dataset.action) {
    case 'edit-member': if (member) openMemberDialog(member); break;
    case 'delete-member': if (member) deleteMember(member); break;
    case 'add-member': openMemberDialog(); break;
    case 'clear-member-search':
      $('#member-search').value = '';
      loadMembers();
      break;
    default: break;
  }
});

$('#add-member-btn').addEventListener('click', () => openMemberDialog());
$('#member-search').addEventListener('input', debounce(loadMembers, 250));

/* ============================== Issue / Return ============================== */
const issueForm = $('#issue-form');
const issueMember = $('#issue-member');
const issueBook = $('#issue-book');
const issueDate = $('#issue-date');
const issueDue = $('#issue-due');
const activeGate = createRequestGate();
let pendingIssueBookId = null;

function resetIssueDates() {
  issueDate.value = todayISO();
  issueDue.value = addDays(todayISO(), 14);
}

async function loadIssueView() {
  if (!issueDate.value) resetIssueDates();
  await Promise.all([loadIssueOptions(), loadActive()]);
}

async function loadIssueOptions() {
  const previousMember = issueMember.value;
  const previousBook = pendingIssueBookId !== null ? String(pendingIssueBookId) : issueBook.value;
  issueMember.innerHTML = '<option value="">Loading members...</option>';
  issueBook.innerHTML = '<option value="">Loading books...</option>';

  try {
    const [members, books] = await Promise.all([
      api('/api/members'),
      api('/api/books?availability=available'),
    ]);

    issueMember.innerHTML = members.data.length
      ? '<option value="">Select a member</option>' +
        members.data.map((m) => `<option value="${m.id}">${esc(m.name)} (ID ${m.id})</option>`).join('')
      : '<option value="">No members registered yet</option>';

    issueBook.innerHTML = books.data.length
      ? '<option value="">Select a book</option>' +
        books.data.map((b) => `<option value="${b.id}">${esc(b.title)} - ${esc(b.author)} (${b.available_copies} available)</option>`).join('')
      : '<option value="">No books are available right now</option>';

    if (members.data.some((m) => String(m.id) === previousMember)) issueMember.value = previousMember;
    if (books.data.some((b) => String(b.id) === previousBook)) issueBook.value = previousBook;
    pendingIssueBookId = null;
  } catch (error) {
    console.error(error);
    issueMember.innerHTML = '<option value="">Could not load members</option>';
    issueBook.innerHTML = '<option value="">Could not load books</option>';
    showFormMessage(issueForm, error instanceof ApiFailure ? error.message : 'Could not load the form options.');
  }
}

issueDate.addEventListener('change', () => {
  if (issueDate.value && (!issueDue.value || issueDue.value < issueDate.value)) {
    issueDue.value = addDays(issueDate.value, 14);
  }
});

issueForm.addEventListener('submit', (event) => {
  event.preventDefault();
  clearErrors(issueForm);

  const payload = {
    member_id: parseWholeNumber(issueMember.value),
    book_id: parseWholeNumber(issueBook.value),
    issue_date: issueDate.value,
    due_date: issueDue.value,
  };
  const errors = {};
  if (!payload.member_id) errors.member_id = 'Select a member.';
  if (!payload.book_id) errors.book_id = 'Select a book.';
  if (!payload.issue_date) errors.issue_date = 'Issue date is required.';
  if (!payload.due_date) errors.due_date = 'Due date is required.';
  else if (payload.issue_date && payload.due_date < payload.issue_date) {
    errors.due_date = 'Due date cannot be earlier than the issue date.';
  }
  if (Object.keys(errors).length) {
    showFieldErrors(issueForm, errors);
    return;
  }

  submitForm({
    form: issueForm,
    button: $('#issue-submit'),
    busyLabel: 'Issuing',
    request: () => api('/api/transactions/issue', { method: 'POST', body: payload }),
    onSuccess: (response) => {
      toast(response.message);
      issueMember.value = '';
      issueBook.value = '';
      resetIssueDates();
      invalidate();
      showFormMessage(issueForm, response.message, 'ok');
    },
  });
});

async function loadActive() {
  const q = $('#active-search').value.trim();
  const url = q ? `/api/transactions/active?q=${encodeURIComponent(q)}` : '/api/transactions/active';
  await fetchInto({
    gate: activeGate,
    container: $('#active-content'),
    label: 'Loading issued books',
    url,
    retryView: 'issue',
    render: (response) => {
      state.active = response.data;
      renderActive(Boolean(q));
    },
  });
}

function renderActive(filtered) {
  const container = $('#active-content');
  const count = state.active.length;
  $('#active-count').textContent = `${count} ${plural(count, 'book', 'books')} out`;

  if (count === 0) {
    container.innerHTML = filtered
      ? emptyBlock({ title: 'No issued books match', text: 'Try a different book title or member name.' })
      : emptyBlock({ title: 'Nothing is out on loan', text: 'Books you issue will be listed here until they are returned.' });
    return;
  }

  container.innerHTML = `
    <div class="table-scroll"><table>
      <thead><tr>
        <th scope="col">ID</th><th scope="col">Book</th><th scope="col">Member</th>
        <th scope="col">Due date</th><th scope="col">Status</th><th scope="col" class="col-actions">Action</th>
      </tr></thead>
      <tbody>${state.active.map((t) => `
        <tr data-txn-id="${t.id}">
          <td data-label="ID">${t.id}</td>
          <td class="cell-main" data-label="Book"><div class="cell-title"><strong>${esc(t.book_title)}</strong></div></td>
          <td data-label="Member">${esc(t.member_name)}</td>
          <td data-label="Due date">${fmtDate(t.due_date)}</td>
          <td data-label="Status">${transactionBadge(t)}</td>
          <td class="cell-actions-td"><div class="cell-actions">
            <button type="button" class="btn btn-ghost btn-sm" data-action="return-book" data-id="${t.id}"
              aria-label="Return ${esc(t.book_title)} from ${esc(t.member_name)}">${icon('undo', 15)}Return</button>
          </div></td>
        </tr>`).join('')}</tbody>
    </table></div>`;
}

async function returnBook(txn) {
  const lateNote = txn.is_overdue ? ' It is past the due date.' : '';
  const confirmed = await confirmAction({
    title: 'Return this book?',
    message: `"${txn.book_title}" borrowed by ${txn.member_name} on ${fmtDate(txn.issue_date)}, due ${fmtDate(txn.due_date)}.${lateNote}`,
    confirmLabel: 'Mark as returned',
  });
  if (!confirmed) return;
  try {
    const response = await api('/api/transactions/return', { method: 'POST', body: { transaction_id: txn.id } });
    toast(response.message);
    invalidate();
  } catch (error) {
    reportError(error);
    invalidate(); // the record may have changed elsewhere, so show the latest state
  }
}

$('#active-content').addEventListener('click', (event) => {
  const button = event.target.closest('[data-action="return-book"]');
  if (!button) return;
  const txn = state.active.find((t) => t.id === Number(button.dataset.id));
  if (txn) returnBook(txn);
});
$('#active-search').addEventListener('input', debounce(loadActive, 250));

/* ============================== Transactions ============================== */
const txnGate = createRequestGate();
let txnStatus = '';

async function loadTransactions() {
  const params = new URLSearchParams();
  if (txnStatus) params.set('status', txnStatus);
  const q = $('#txn-search').value.trim();
  if (q) params.set('q', q);
  const filtered = params.toString() !== '';

  await fetchInto({
    gate: txnGate,
    container: $('#txn-content'),
    label: 'Loading transactions',
    url: filtered ? `/api/transactions?${params}` : '/api/transactions',
    retryView: 'transactions',
    render: (response) => renderTransactions(response.data, filtered),
  });
}

function renderTransactions(items, filtered) {
  const container = $('#txn-content');
  $('#txn-count').textContent = `${items.length} ${plural(items.length, 'transaction', 'transactions')}${filtered ? ' found' : ' recorded'}`;

  if (items.length === 0) {
    container.innerHTML = filtered
      ? emptyBlock({ title: 'No transactions match', text: 'Try another filter or search term.' })
      : emptyBlock({ title: 'No transactions yet', text: 'Issue a book to a member and the record will appear here.' });
    return;
  }

  container.innerHTML = `
    <div class="table-scroll"><table>
      <thead><tr>
        <th scope="col">ID</th><th scope="col">Book</th><th scope="col">Member</th>
        <th scope="col">Issue date</th><th scope="col">Due date</th><th scope="col">Return date</th><th scope="col">Status</th>
      </tr></thead>
      <tbody>${items.map((t) => `
        <tr>
          <td data-label="ID">${t.id}</td>
          <td class="cell-main" data-label="Book"><div class="cell-title"><strong>${esc(t.book_title)}</strong></div></td>
          <td data-label="Member">${esc(t.member_name)}</td>
          <td data-label="Issue date">${fmtDate(t.issue_date)}</td>
          <td data-label="Due date">${fmtDate(t.due_date)}</td>
          <td data-label="Return date">${t.return_date ? fmtDate(t.return_date) : '<span class="muted">Not returned</span>'}</td>
          <td data-label="Status">${transactionBadge(t)}</td>
        </tr>`).join('')}</tbody>
    </table></div>`;
}

$('#txn-filter').addEventListener('click', (event) => {
  const button = event.target.closest('button[data-status]');
  if (!button) return;
  txnStatus = button.dataset.status;
  $$('#txn-filter button').forEach((b) => b.setAttribute('aria-pressed', String(b === button)));
  loadTransactions();
});
$('#txn-search').addEventListener('input', debounce(loadTransactions, 250));

/* ------------------------------ 5. Navigation + start-up ------------------------------ */
const sidebar = $('#sidebar');
const menuButton = $('#menu-btn');
const narrowScreen = window.matchMedia('(max-width: 900px)');

function syncSidebarAccess() {
  // On phones the closed sidebar must not be reachable with the Tab key.
  sidebar.inert = narrowScreen.matches && !document.body.classList.contains('nav-open');
}
function openNav() {
  document.body.classList.add('nav-open');
  menuButton.setAttribute('aria-expanded', 'true');
  syncSidebarAccess();
}
function closeNav() {
  document.body.classList.remove('nav-open');
  menuButton.setAttribute('aria-expanded', 'false');
  syncSidebarAccess();
}
menuButton.addEventListener('click', () => (document.body.classList.contains('nav-open') ? closeNav() : openNav()));
$('#scrim').addEventListener('click', closeNav);
document.addEventListener('keydown', (event) => { if (event.key === 'Escape') closeNav(); });
narrowScreen.addEventListener('change', () => { closeNav(); });

function showView(name) {
  currentView = name;
  $$('.view').forEach((section) => { section.hidden = section.id !== `view-${name}`; });
  $$('.nav a').forEach((link) => {
    if (link.dataset.view === name) link.setAttribute('aria-current', 'page');
    else link.removeAttribute('aria-current');
  });
  $('#page-title').textContent = VIEW_TITLES[name];
  document.title = `${VIEW_TITLES[name]} | Library Management System`;
  closeNav();
  window.scrollTo(0, 0);

  if (views[name].dirty) {
    views[name].dirty = false;
    views[name].load();
  }
}

function route() {
  const name = (location.hash || '#dashboard').slice(1);
  showView(Object.prototype.hasOwnProperty.call(views, name) ? name : 'dashboard');
}
window.addEventListener('hashchange', route);

// "Try again" buttons inside error blocks
document.addEventListener('click', (event) => {
  const retry = event.target.closest('[data-retry]');
  if (!retry) return;
  const name = retry.dataset.retry;
  if (views[name]) {
    views[name].dirty = false;
    views[name].load();
  }
});

// Search box in the top bar jumps to the Books page.
$('#global-search').addEventListener('submit', (event) => {
  event.preventDefault();
  $('#book-search').value = $('#global-search-input').value.trim();
  $('#book-category').value = '';
  $('#book-availability').value = '';
  if (currentView === 'books') {
    loadBooks();
  } else {
    views.books.dirty = true;
    location.hash = '#books';
  }
});

// Static icons in the HTML (sidebar, buttons)
$$('[data-icon]').forEach((el) => {
  el.innerHTML = icon(el.dataset.icon, Number(el.dataset.size) || 18);
  el.style.display = 'inline-grid';
});

$('#today-label').textContent = new Date().toLocaleDateString('en-IN', {
  weekday: 'long', day: 'numeric', month: 'long', year: 'numeric',
});

resetIssueDates();
syncSidebarAccess();
route();

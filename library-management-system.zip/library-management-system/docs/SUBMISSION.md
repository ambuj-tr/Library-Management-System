# Library Management System: Submission Notes

MDM-III Web Development, Technical Assignment, Aim 4

---

## 1. Project explanation (for submission)

The Library Management System is a full-stack web application that helps a librarian manage books, members and book loans from a single dashboard. It is built with HTML5, CSS3 and vanilla JavaScript on the frontend, a Python Flask REST API on the backend, and a SQLite database for storage.

The browser never talks to the database directly. The JavaScript code sends JSON requests to the Flask API using the Fetch API (GET, POST, PUT and DELETE). Flask validates the data, applies the library rules, runs parameterized SQL queries against SQLite and returns a JSON response with a suitable HTTP status code (200, 201, 400, 404, 409 or 500). The page then updates the relevant table, card or message without reloading.

The application supports full CRUD for books and members, live search and filters, issuing and returning books, and a transaction history that is never erased. The most important logic is in the issue and return operations. Issuing a book lowers its available count and records a transaction as one atomic database transaction. Returning a book raises the count only once and marks the transaction as returned, so stock can never go negative or be counted twice. Foreign keys, `UNIQUE` and `CHECK` constraints protect the data at the database level, and every rule is validated again on the server because client-side checks can be bypassed.

The interface is a responsive dashboard with a sidebar, a top bar, status badges, loading indicators, empty states and toast notifications, using a navy, white and teal palette.

## 2. Architecture

```
 ┌───────────────────────────┐      HTTP + JSON      ┌───────────────────────────┐      SQL       ┌───────────────┐
 │  FRONTEND (browser)       │  (Fetch API requests) │  FLASK REST API           │  (parameterized│  SQLite       │
 │  index.html  style.css    │ ────────────────────► │  app.py  validators.py    │ ─────────────► │  library.db   │
 │  script.js                │ ◄──────────────────── │  database.py              │ ◄───────────── │  books        │
 │  renders pages, validates │   JSON + status code  │  rules, validation, SQL   │   rows         │  members      │
 └───────────────────────────┘                       └───────────────────────────┘                │  transactions │
                                                                                                  └───────────────┘
```

```mermaid
flowchart LR
    A["Frontend<br/>HTML, CSS, JavaScript"] -- "Fetch API: HTTP + JSON" --> B["Flask REST API<br/>app.py"]
    B -- "parameterized SQL" --> C[("SQLite<br/>library.db")]
    C -- "rows" --> B
    B -- "JSON + status code" --> A
```

Request example (issuing a book):

1. The user submits the Issue form. `script.js` checks the fields, then calls `fetch('/api/transactions/issue', { method: 'POST', body: JSON.stringify({...}) })`.
2. Flask validates the JSON (`validators.py`), opens a database transaction, checks the member and book exist, decreases `available_copies` only if it is above zero, and inserts the transaction row.
3. Flask returns `201` with the new transaction and a message. On a rule violation it returns `404`, `409` or `400` with a readable error.
4. `script.js` shows a toast, refreshes the tables and updates the dashboard numbers.

## 3. Database design

```
books                         transactions                       members
─────────────────────         ────────────────────────────       ─────────────────────
id (PK)                       id (PK)                            id (PK)
title                         book_id    (FK → books.id)         name
author                        member_id  (FK → members.id)       email  (UNIQUE)
isbn  (UNIQUE)                issue_date                         phone
category                      due_date                           registration_date
total_copies                  return_date (NULL until returned)
available_copies              status ('Issued' | 'Returned')
```

One book has many transactions, and one member has many transactions (one-to-many relationships). The transactions table links the two. Extra safety rules in `schema.sql`: `total_copies >= 1`, `0 <= available_copies <= total_copies`, `due_date >= issue_date`, and "an issued row has no return date, a returned row always has one".

## 4. Test cases and results

Expected results below were checked by automated tests (`python test_api.py`, 21 tests) and by a scripted browser run (49 checks in headless Chromium against the live server). All passed in the final run.

| # | Test case | Expected result | Result |
|---|---|---|---|
| 1 | Add a book | `201`, book appears in the list with available copies equal to total copies | Passed |
| 2 | View and search books (title, author, ISBN with or without hyphens, category) | Matching books only | Passed |
| 3 | Update a book (change title, category, total copies) | `200`; available copies recalculated (new total minus issued) | Passed |
| 4 | Delete a book with no history | `200`; book removed | Passed |
| 5 | Add a book with empty fields, bad ISBN, negative, zero, decimal or text copies | `400`; field-level error messages; nothing saved | Passed |
| 6 | Add, view, search, update and delete a member | `201`, list, matches by name, email or ID, `200`, `200` | Passed |
| 7 | Add a member with bad email, short phone or short name | `400` with field errors | Passed |
| 8 | Issue an available book | `201`; available copies down by 1; dashboard issued count up by 1 | Passed |
| 9 | Issue a book with 0 copies left | `409` "No copies available"; stock stays 0; no transaction created | Passed |
| 10 | Issue with due date before issue date, unknown member, unknown book, missing fields, invalid date | `400` / `404`; nothing recorded; stock unchanged | Passed |
| 11 | Return an issued book | `200`; status Returned; return date set; available copies up by 1; history kept | Passed |
| 12 | Return the same transaction again | `409` "already returned"; stock does not increase again | Passed |
| 13 | Return date earlier than issue date | `400`; transaction stays active | Passed |
| 14 | Search for a book that does not exist | `200` with an empty list; the UI shows a "No books match" empty state | Passed |
| 15 | Search text such as `x' OR '1'='1` or `%` | Treated as plain text; no matches; data intact | Passed |
| 16 | Add a duplicate ISBN (including a hyphenated form of an existing one) | `409`; error shown beside the ISBN field | Passed |
| 17 | Add a duplicate member email (different upper/lower case) | `409`; error shown beside the email field | Passed |
| 18 | Edit a book or member into an existing ISBN or email | `409` | Passed |
| 19 | Delete a book with an active issue | `409` with a readable message; book stays | Passed |
| 20 | Delete a member who still holds a book | `409`; member stays | Passed |
| 21 | Delete a book or member that only has past (returned) transactions | `409`; history is preserved | Passed |
| 22 | Lower total copies below the number currently issued | `409` | Passed |
| 23 | Dashboard statistics after each operation | available + issued always equals total copies; member and book counts correct | Passed |
| 24 | Overdue detection | A loan past its due date shows an "Overdue" badge and a dashboard warning | Passed |
| 25 | Unknown API URL / wrong HTTP method | JSON `404` / `405` | Passed |
| 26 | Foreign keys and CHECK constraints at the database level | SQLite rejects a transaction for a missing book and a negative stock value | Passed |
| 27 | 12 simultaneous requests to issue the last copy of a book | Exactly one `201`; eleven `409`; stock is 0 | Passed |
| 28 | 12 simultaneous requests to return the same transaction | Exactly one `200`; eleven `409`; stock increases by exactly 1 | Passed |
| 29 | Responsive layout at 1366, 1180, 820 and 390 pixel widths | No page-level sideways scrolling; sidebar becomes a slide-in menu; tables become stacked cards on phones | Passed |

### What was and was not tested

Done in the build environment (Linux, Python 3.12, Flask 3.1, SQLite 3.45, headless Chromium 141):

- All automated API tests and the browser run described above.
- Starting the real server and calling endpoints over HTTP, including the two concurrency tests (27 and 28).
- Checking the interface at desktop, tablet and phone widths using screenshots.

**Not tested:**

- Running on Windows with VS Code. The commands in the README are standard Windows commands, but they were not run on Windows.
- Real phones and tablets (only emulated screen sizes), and browsers other than Chromium (Firefox, Safari, Edge).
- Heavy load or very large data sets (the demo data has 16 books and 7 members).
- Screen-reader testing. Labels, focus styles, dialog semantics and keyboard use were built in, but no assistive technology was used.

## 5. Viva questions and answers

### HTML

**1. Why did you use `<dialog>` for the forms?**
`<dialog>` is the built-in HTML element for popups. `showModal()` dims the page, traps keyboard focus inside and closes with the Esc key, so no extra library is needed.

**2. What is semantic HTML and where did you use it?**
Semantic elements describe meaning: `<aside>` for the sidebar, `<nav>` for navigation links, `<header>` for the top bar, `<main>` for the main content, `<section>` for each page area, `<table>` with `<th scope="col">` for data. This helps accessibility and search engines.

**3. What is the difference between `<div>` and `<section>`?**
`<div>` has no meaning and is only a container. `<section>` marks a thematic part of the page and normally has a heading.

**4. Why does every input have a `<label>`?**
A label with `for="id"` tells screen readers what the field is and lets users click the label to focus the input. Visually hidden labels (`sr-only`) are used on search boxes.

**5. What does `novalidate` on a form do?**
It switches off the browser's default validation popups so my own JavaScript can show consistent error messages next to each field.

### CSS

**6. How is the layout responsive?**
I used CSS Grid and Flexbox, relative widths and `@media` queries. At 900 pixels and below the sidebar becomes a slide-in menu opened with a button. At 720 pixels and below each table row turns into a stacked card using `td::before { content: attr(data-label) }`.

**7. What are CSS variables and why use them?**
Custom properties like `--navy-900` and `--teal-600` are defined once in `:root` and reused everywhere, so the whole colour theme can be changed in one place.

**8. What is the difference between Flexbox and Grid?**
Flexbox lays items out in one direction (a row or a column). Grid lays items out in rows and columns together. I used Grid for the statistic band and the two-column panels, and Flexbox for toolbars and rows.

**9. Why `minmax(0, 1fr)` in the grid?**
A plain `1fr` column will not shrink below the width of its longest unbreakable content. `minmax(0, 1fr)` allows it to shrink, which fixed sideways scrolling on phones.

**10. How do you respect users who prefer less motion?**
`@media (prefers-reduced-motion: reduce)` shortens animations to almost nothing.

### JavaScript

**11. What is the Fetch API?**
`fetch()` sends HTTP requests from JavaScript and returns a Promise. I wrap it in one `api()` function that sets JSON headers, parses the response, and converts network errors and error status codes into readable messages.

**12. What are `async` and `await`?**
They make Promise-based code read like normal step-by-step code. `await` pauses inside an `async` function until the request finishes, without freezing the page.

**13. How does live search work without reloading the page?**
Each keystroke (debounced by 250 ms) calls `/api/books/search?q=...`. The table body is re-rendered from the returned JSON. An `AbortController` cancels older requests so a slow response cannot overwrite a newer one.

**14. What is debouncing?**
Waiting until the user stops typing for a short time before sending a request, so fast typing does not cause a request per letter.

**15. How do you prevent XSS (script injection) in the table?**
Every value that comes from the database passes through an `esc()` function that converts `<`, `>`, `&` and quotes into HTML entities before it is placed in the page.

**16. Why validate in JavaScript if Flask validates too?**
JavaScript validation gives instant feedback. Flask validation is the real protection, because a user can bypass the browser with tools such as Postman or curl.

**17. How does the page change sections without reloading?**
The sidebar links change the URL hash (`#books`). A `hashchange` listener shows the matching `<section>` and hides the others, then loads that section's data.

### Flask and REST

**18. What is Flask?**
A lightweight Python web framework. A function decorated with `@app.get('/api/books')` runs when the browser requests that URL, and returns data as JSON.

**19. What is REST?**
An architecture style where each resource (books, members, transactions) has a URL, and the HTTP method says what to do with it: GET to read, POST to create, PUT to update, DELETE to remove. Data travels as JSON and the server keeps no session state between requests.

**20. What is JSON?**
A lightweight text format for data, made of key-value pairs and lists, for example `{"title": "Clean Code", "total_copies": 3}`. Both JavaScript and Python read it easily.

**21. Which HTTP status codes did you use and why?**
`200` OK, `201` Created (after a successful POST), `400` Bad Request (invalid input), `404` Not Found (missing record), `405` Method Not Allowed, `409` Conflict (duplicate ISBN, no copies, already returned, blocked delete) and `500` for unexpected server errors.

**22. What is the difference between GET, POST, PUT and DELETE?**
GET reads data and changes nothing. POST creates something new. PUT replaces or updates an existing record. DELETE removes a record.

**23. Why is issuing a book a POST and not a PUT?**
It creates a new transaction record and has side effects (stock changes), so POST fits. A PUT is meant to update a known record.

**24. Why does Flask serve the frontend too?**
When the page and API come from the same address (`127.0.0.1:5000`), the browser allows the Fetch calls without any CORS configuration. Opening `index.html` directly from disk would not work.

**25. How are errors handled?**
I raise an `ApiError(message, status)` for expected problems and register error handlers that turn it into a JSON response. Unexpected exceptions are logged with a full traceback in the terminal and a generic `500` JSON is returned. Nothing is silently ignored.

**26. What is the Flask `g` object?**
It stores data for one request. I keep that request's database connection in it and close the connection when the request ends (`teardown_appcontext`).

### SQLite and SQL

**27. Why SQLite?**
It is a serverless database stored in one file (`library.db`), needs no installation (Python includes the `sqlite3` module) and is ideal for small applications and college projects.

**28. What is a primary key and what does `AUTOINCREMENT` do?**
A primary key uniquely identifies each row. `AUTOINCREMENT` makes SQLite assign the next number automatically and never reuse an old ID.

**29. What does `UNIQUE` do, and how is it used here?**
It stops two rows from having the same value. `books.isbn` and `members.email` are unique, so duplicates are rejected both by my code (with a friendly message) and by the database itself.

**30. What is a parameterized query and why use it?**
A query where values are passed separately, for example `execute("SELECT * FROM books WHERE id = ?", (book_id,))`. The database treats the value strictly as data, so input like `' OR '1'='1` cannot change the query. This prevents SQL injection.

**31. What is a `JOIN`?**
It combines rows from related tables. The transaction list joins `transactions` with `books` and `members` so each row shows the book title and member name instead of just ID numbers.

**32. What is a `CHECK` constraint?**
A rule the database enforces on every insert and update. For example `available_copies >= 0` makes negative stock impossible even if a program has a bug.

### CRUD

**33. What is CRUD and how does each part map to HTTP and SQL?**
Create is POST and `INSERT`. Read is GET and `SELECT`. Update is PUT and `UPDATE`. Delete is DELETE and `DELETE`. Books and members both have all four.

**34. What happens to available copies when you edit a book's total copies?**
The server computes `issued = total − available` for the book, rejects a new total below that number, and sets `available = new total − issued`. Copies out on loan stay accounted for.

### Foreign keys

**35. What is a foreign key?**
A column that points to the primary key of another table. `transactions.book_id` references `books.id` and `transactions.member_id` references `members.id`, so a transaction cannot exist for a book or member that does not exist.

**36. SQLite ignores foreign keys by default. How did you enable them?**
By running `PRAGMA foreign_keys = ON` on every new connection in `connect()`. The tests confirm that inserting a transaction for a missing book is rejected.

**37. Why can't a book that was returned earlier be deleted?**
Its past transactions still reference it. Deleting the book would either break the foreign key or erase history, and the requirement is to keep history. So the server returns `409` with a clear message.

### Issue and return logic

**38. How does issuing work step by step?**
Validate the input, then inside one transaction: confirm the member exists, confirm the book exists, run `UPDATE books SET available_copies = available_copies - 1 WHERE id = ? AND available_copies > 0`, stop with `409` if no row was changed, then insert the transaction. Commit if all steps succeed.

**39. Why `AND available_copies > 0` in the UPDATE?**
It makes the check and the decrease a single atomic step. If two librarians click at the same moment for the last copy, only one UPDATE changes a row. I tested this with 12 simultaneous requests: one succeeded and eleven were rejected.

**40. What is a database transaction?**
A group of SQL statements that either all succeed or all are undone. If recording the transaction failed after stock was reduced, `ROLLBACK` would restore the stock. `BEGIN IMMEDIATE` locks the database for writing at the start so two writers cannot interleave.

**41. How do you prevent returning the same book twice?**
The return runs `UPDATE transactions SET status = 'Returned', return_date = ? WHERE id = ? AND status = 'Issued'`. Only the first request changes a row. Stock is increased only after that succeeds, and a second request gets `409`.

**42. How is an overdue book detected?**
A transaction is overdue when its status is `Issued` and its `due_date` is earlier than today's date. The API adds an `is_overdue` flag and the dashboard counts them.

**43. How is transaction history preserved?**
Returning a book never deletes the row. It only sets `return_date` and changes `status` to `Returned`, and foreign keys stop the related book or member from being deleted.

### General

**44. What is the role of `schema.sql` and when does it run?**
It holds the `CREATE TABLE IF NOT EXISTS` statements. `init_db()` runs it every time the app starts, so the database and tables are created automatically, and existing data is untouched.

**45. What would you improve with more time?**
User login and roles for librarians, fines for overdue books, pagination for large catalogues, book renewal, email reminders, and moving from the Flask development server to a production server.
